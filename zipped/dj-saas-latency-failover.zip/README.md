
SMART LATENCY FAILOVER SYSTEM

System measures node latency and automatically selects fastest LiveKit server.

Login:
dj1 / 1234
pub1 / 1234
