
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { AccessToken } = require("livekit-server-sdk");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="LATENCY_FAILOVER_SECRET";

// Nodes with simulated latency values
let LIVEKIT_NODES = [
  { url:"ws://localhost:7880", key:"devkey", secret:"secret", lat:33.8938, lng:35.5018, latency:40 },
  { url:"ws://localhost:7882", key:"devkey", secret:"secret", lat:48.8566, lng:2.3522, latency:90 },
  { url:"ws://localhost:7884", key:"devkey", secret:"secret", lat:40.7128, lng:-74.0060, latency:120 }
];

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

// 🌍 Smart latency + geo decision
function chooseBestNode(userLat,userLng){

  // simulate latency change
  LIVEKIT_NODES.forEach(n=>{
    n.latency = Math.floor(Math.random()*150)+20;
  });

  // choose lowest latency node
  let best = LIVEKIT_NODES[0];
  LIVEKIT_NODES.forEach(n=>{
    if(n.latency < best.latency){
      best = n;
    }
  });

  return best;
}

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=?",[username],async(err,rows)=>{
    if(!rows || rows.length===0) return res.status(401).send("Invalid");

    const user=rows[0];
    const match = await bcrypt.compare(password,user.password);
    if(!match) return res.status(401).send("Invalid");

    const token = jwt.sign({
      id:user.id,
      role:user.role,
      approved:user.approved
    },AUTH_SECRET,{expiresIn:"2h"});

    res.json({accessToken:token,user:{username:user.username,role:user.role}});
  });
});

// 🚀 SMART LATENCY FAILOVER TOKEN
app.get("/smart-token",auth,(req,res)=>{

  const lat = parseFloat(req.query.lat || "0");
  const lng = parseFloat(req.query.lng || "0");

  const node = chooseBestNode(lat,lng);

  const at = new AccessToken(node.key,node.secret,{
    identity:"user-"+req.user.id
  });

  at.addGrant({
    roomJoin:true,
    room:"global-broadcast-room",
    canPublish:req.user.role==="dj",
    canSubscribe:true
  });

  res.send("BEST NODE: "+node.url+" (latency "+node.latency+"ms) | TOKEN: "+at.toJwt());
});

app.listen(4000,()=>console.log("Smart Latency Failover API running"));
