
import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);
  const audioRef = useRef(null);

  useEffect(()=>{

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 🎧 Stage
    const stage = new THREE.Mesh(
      new THREE.BoxGeometry(4,0.5,4),
      new THREE.MeshBasicMaterial({wireframe:true})
    );
    stage.position.y = 0.25;
    scene.add(stage);

    // 🔥 Pyro particles
    const pyroGeo = new THREE.BufferGeometry();
    const particleCount = 200;
    const positions = new Float32Array(particleCount*3);

    for(let i=0;i<particleCount;i++){
      positions[i*3] = (Math.random()-0.5)*2;
      positions[i*3+1] = Math.random()*3;
      positions[i*3+2] = (Math.random()-0.5)*2;
    }

    pyroGeo.setAttribute("position", new THREE.BufferAttribute(positions,3));

    const pyroMat = new THREE.PointsMaterial({
      size:0.1
    });

    const pyro = new THREE.Points(pyroGeo,pyroMat);
    pyro.visible = false;
    scene.add(pyro);

    camera.position.set(0,6,10);
    camera.lookAt(0,0,0);

    // 🔊 Audio analyser
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    const audio = audioRef.current;
    const source = ctx.createMediaElementSource(audio);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser).connect(ctx.destination);

    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    let lastEnergy = 0;

    function animate(){
      requestAnimationFrame(animate);

      analyser.getByteFrequencyData(dataArray);

      let sum=0;
      for(let i=0;i<dataArray.length;i++){
        sum+=dataArray[i];
      }

      const energy = sum/dataArray.length/255;

      // 🤖 Beat Drop Detection
      if(energy - lastEnergy > 0.25){
        pyro.visible = true;
        setTimeout(()=>{
          pyro.visible=false;
        },300);
      }

      lastEnergy = energy;

      // Pyro animation
      pyro.rotation.y += 0.05 + energy*0.2;

      // Camera shake effect
      camera.position.x = Math.sin(Date.now()*0.02)*energy*0.5;

      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#000"}}>
      <h1 style={{position:"absolute",color:"#ff3300",padding:15}}>
        🎆 AI Beat Drop Pyro FX System
      </h1>

      <audio
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      />

      <div style={{position:"absolute",top:60,left:20,color:"#fff"}}>
        <button onClick={()=>audioRef.current.play()}>Play Music</button>
      </div>

      <div ref={mountRef}></div>
    </div>
  );
}
