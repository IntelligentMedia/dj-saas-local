
AI BEAT DROP PYRO FX SYSTEM

Features:
- Beat drop detection using audio energy spikes
- Pyro particle explosions
- Camera shake effect
- Designed for DJ metaverse stages
