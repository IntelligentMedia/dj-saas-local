
REALTIME MULTIPLAYER SYNC ENGINE

Features:
- WebSocket realtime avatar sync
- Multi-user metaverse room
- Arrow key movement broadcasting
- Foundation for LiveKit avatar sync
