
import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);

  useEffect(()=>{

    const socket = new WebSocket("ws://localhost:4001");

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // Floor
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(20,20),
      new THREE.MeshBasicMaterial({wireframe:true})
    );
    floor.rotation.x = -Math.PI/2;
    scene.add(floor);

    const avatars = {};

    function createAvatar(id,color=0x00f0ff){
      const mat = new THREE.MeshBasicMaterial({color,wireframe:true});
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.4,16,16),mat);
      head.position.y = 1.5;

      const body = new THREE.Mesh(new THREE.BoxGeometry(0.8,1.5,0.4),mat);
      body.position.y = 0.5;

      const group = new THREE.Group();
      group.add(head);
      group.add(body);
      scene.add(group);
      avatars[id] = group;
    }

    socket.onmessage = (msg)=>{
      const data = JSON.parse(msg.data);

      if(!avatars[data.id]){
        createAvatar(data.id, Math.random()*0xffffff);
      }

      const a = avatars[data.id];
      a.position.set(data.x,0,data.z);
    };

    camera.position.set(0,6,10);
    camera.lookAt(0,0,0);

    // Send local movement
    let x=0,z=0;

    window.addEventListener("keydown",(e)=>{
      if(e.key==="ArrowLeft") x-=0.3;
      if(e.key==="ArrowRight") x+=0.3;
      if(e.key==="ArrowUp") z-=0.3;
      if(e.key==="ArrowDown") z+=0.3;

      socket.send(JSON.stringify({x,z}));
    });

    function animate(){
      requestAnimationFrame(animate);
      Object.values(avatars).forEach(a=>{
        a.rotation.y += 0.01;
      });
      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#000"}}>
      <h1 style={{position:"absolute",color:"#00f0ff",padding:15,textShadow:"0 0 10px #00f0ff"}}>
        🌐 Realtime Multiplayer Sync Engine
      </h1>
      <div style={{position:"absolute",top:60,left:20,color:"#fff"}}>
        Use Arrow Keys to Move Avatar
      </div>
      <div ref={mountRef}></div>
    </div>
  );
}
