
const WebSocket = require("ws");

const wss = new WebSocket.Server({ port:4001 });

let clients = new Map();
let idCounter = 1;

wss.on("connection",(ws)=>{

  const id = idCounter++;
  clients.set(ws,{id,x:0,z:0});

  ws.on("message",(msg)=>{
    const data = JSON.parse(msg);
    const client = clients.get(ws);
    client.x = data.x;
    client.z = data.z;

    broadcast();
  });

  ws.on("close",()=>{
    clients.delete(ws);
  });
});

function broadcast(){
  const payload = Array.from(clients.values());
  wss.clients.forEach(client=>{
    if(client.readyState===1){
      payload.forEach(p=>{
        client.send(JSON.stringify(p));
      });
    }
  });
}

console.log("Realtime Multiplayer Sync Server running on ws://localhost:4001");
