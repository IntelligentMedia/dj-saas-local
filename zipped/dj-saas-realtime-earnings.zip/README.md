
REALTIME EARNINGS METER

Features:
- Live DJ earnings counter
- Platform revenue tracking
- Session timer
- Auto updating every 2 seconds

Login:
dj1 / 1234
pub1 / 1234
