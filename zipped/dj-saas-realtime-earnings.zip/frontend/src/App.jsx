
import React, { useState, useEffect } from "react";

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [earnings,setEarnings]=useState("Waiting...");

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const data=await res.json();
      localStorage.setItem("auth",data.accessToken);
      setUser(data.user);
    }else alert("Login failed");
  };

  useEffect(()=>{
    if(!user) return;

    const interval = setInterval(async()=>{
      const res = await fetch("http://localhost:4000/realtime-earnings",{
        headers:{Authorization:"Bearer "+localStorage.getItem("auth")}
      });

      const text = await res.text();
      setEarnings(text);
    },2000);

    return ()=>clearInterval(interval);
  },[user]);

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Login</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return(
    <div style={{padding:20}}>
      <h1>{user.username} ({user.role})</h1>
      <h2>💰 Realtime Earnings Meter</h2>
      <pre>{earnings}</pre>
    </div>
  );
}
