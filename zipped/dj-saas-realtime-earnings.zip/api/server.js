
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="REALTIME_EARNINGS_SECRET";

// Simulated live session state
let session = {
  pub:"Pub Beirut",
  dj:"DJ Sam",
  ratePerHour:50,
  startTime:Date.now()
};

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

// Demo login
app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  if(password!=="1234") return res.status(401).send("Invalid");

  const role = username.startsWith("dj") ? "dj":"pub";

  const token = jwt.sign({id:1,role},AUTH_SECRET,{expiresIn:"2h"});
  res.json({accessToken:token,user:{username,role}});
});

// 💰 REALTIME EARNINGS CALCULATION
app.get("/realtime-earnings",auth,(req,res)=>{

  const elapsedMs = Date.now() - session.startTime;
  const elapsedHours = elapsedMs / (1000*60*60);

  const total = elapsedHours * session.ratePerHour;
  const platformFee = total * 0.20;
  const djEarn = total - platformFee;

  let output = "";
  output += "Pub: "+session.pub+"\\n";
  output += "DJ: "+session.dj+"\\n";
  output += "Elapsed Minutes: "+Math.floor(elapsedMs/60000)+"\\n";
  output += "Live Session Total: $"+total.toFixed(2)+"\\n";
  output += "DJ Earnings: $"+djEarn.toFixed(2)+"\\n";
  output += "Platform Revenue: $"+platformFee.toFixed(2)+"\\n";

  res.send(output);
});

app.listen(4000,()=>console.log("Realtime Earnings API running"));
