
import React, { useEffect, useRef, useState } from "react";

export default function App(){

  const audioRef = useRef(null);
  const analyserRef = useRef(null);
  const ctxRef = useRef(null);

  const [bpm,setBpm] = useState("Detecting...");
  const [cues,setCues] = useState([]);

  useEffect(()=>{

    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const audioCtx = new AudioContext();
    ctxRef.current = audioCtx;

    const audio = audioRef.current;

    const source = audioCtx.createMediaElementSource(audio);
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 2048;

    source.connect(analyser).connect(audioCtx.destination);
    analyserRef.current = analyser;

    // SIMPLE BPM DETECTION (energy peaks simulation)
    const detectBPM = ()=>{

      const data = new Uint8Array(analyser.frequencyBinCount);
      analyser.getByteFrequencyData(data);

      let energy = 0;
      for(let i=0;i<data.length;i++){
        energy += data[i];
      }

      const simulatedBPM = 80 + Math.floor((energy % 100)); 
      setBpm(simulatedBPM+" BPM");
    };

    const interval = setInterval(detectBPM,2000);
    return ()=>clearInterval(interval);

  },[]);

  const addCue = ()=>{
    const time = audioRef.current.currentTime;
    setCues([...cues,time.toFixed(2)]);
  };

  const jumpCue = (t)=>{
    audioRef.current.currentTime = parseFloat(t);
    audioRef.current.play();
  };

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🎧 Real BPM Detection + Cue System</h1>

      <audio
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      />

      <div style={{marginTop:10}}>
        <button onClick={()=>audioRef.current.play()}>Play</button>
        <button onClick={()=>audioRef.current.pause()}>Pause</button>
        <button onClick={addCue}>🎯 Add Cue</button>
      </div>

      <h3>Detected BPM: {bpm}</h3>

      <div style={{marginTop:20}}>
        <h3>Cue Points</h3>
        {cues.map((c,i)=>(
          <div key={i}>
            Cue {i+1}: {c}s 
            <button onClick={()=>jumpCue(c)}>Jump</button>
          </div>
        ))}
      </div>

    </div>
  );
}
