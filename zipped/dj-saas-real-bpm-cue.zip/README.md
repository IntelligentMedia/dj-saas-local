
REAL BPM DETECTION + CUE SYSTEM

Features:
- Energy-based BPM detection simulation
- Add Cue Points
- Jump to Cue instantly
