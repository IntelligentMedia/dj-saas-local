
import React, { useEffect, useRef, useState } from "react";

export default function App(){

  const audioA = useRef(null);
  const audioB = useRef(null);
  const ctxRef = useRef(null);
  const gainARef = useRef(null);
  const gainBRef = useRef(null);

  const [status,setStatus] = useState("Idle");

  useEffect(()=>{

    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    ctxRef.current = ctx;

    const srcA = ctx.createMediaElementSource(audioA.current);
    const srcB = ctx.createMediaElementSource(audioB.current);

    const gainA = ctx.createGain();
    const gainB = ctx.createGain();

    gainA.gain.value = 1;
    gainB.gain.value = 0;

    srcA.connect(gainA).connect(ctx.destination);
    srcB.connect(gainB).connect(ctx.destination);

    gainARef.current = gainA;
    gainBRef.current = gainB;

  },[]);

  // 🤖 AI SMART CROSSFADE
  const aiCrossfade = ()=>{

    setStatus("AI Crossfading DJs...");

    let progress = 0;

    const interval = setInterval(()=>{

      progress += 0.02;

      if(progress >= 1){
        progress = 1;
        clearInterval(interval);
        setStatus("AI Switch Complete");
      }

      if(gainARef.current && gainBRef.current){
        gainARef.current.gain.value = 1 - progress;
        gainBRef.current.gain.value = progress;
      }

    },100);

  };

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🤖 AI Smart Crossfade Engine</h1>

      <audio ref={audioA} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"/>
      <audio ref={audioB} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"/>

      <div style={{marginTop:10}}>
        <button onClick={()=>audioA.current.play()}>Play DJ A</button>
        <button onClick={()=>audioB.current.play()}>Play DJ B</button>
      </div>

      <div style={{marginTop:20}}>
        <button onClick={aiCrossfade}>🤖 AI Smart Crossfade</button>
      </div>

      <h3>Status: {status}</h3>

    </div>
  );
}
