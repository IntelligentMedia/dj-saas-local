
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/",(req,res)=>{
  res.send("AI Smart Crossfade Engine Backend Running");
});

app.listen(4000,()=>console.log("AI Smart Crossfade API running"));
