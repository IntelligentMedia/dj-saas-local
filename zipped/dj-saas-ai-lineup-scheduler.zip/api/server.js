
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// 🤖 AI Lineup Scheduler Simulation
app.get("/ai/lineup",(req,res)=>{

  const lineup = [
    {time:"18:00", dj:"DJ Lina", genre:"Lounge"},
    {time:"20:00", dj:"DJ Sam", genre:"House"},
    {time:"22:00", dj:"DJ Alex", genre:"Techno"},
    {time:"00:00", dj:"DJ Rami", genre:"Afro"}
  ];

  res.json(lineup);
});

app.listen(4000,()=>console.log("AI Lineup Scheduler Engine running"));
