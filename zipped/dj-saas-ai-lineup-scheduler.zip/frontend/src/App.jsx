
import React, { useEffect, useState } from "react";

export default function App(){

  const [schedule,setSchedule] = useState(null);

  useEffect(()=>{

    const load = async()=>{
      const res = await fetch("http://localhost:4000/ai/lineup");
      const json = await res.json();
      setSchedule(json);
    };

    load();

  },[]);

  if(!schedule) return <div style={{padding:20}}>🤖 AI Building DJ Lineup...</div>;

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🤖 AI Lineup Scheduler Engine</h1>

      <h3>📅 Recommended Global DJ Schedule</h3>

      <div style={{marginTop:20,background:"#111",color:"#0f0",padding:20,width:600}}>
        {schedule.map((s,i)=>(
          <div key={i}>
            {s.time} → 🎧 {s.dj} → 🎵 {s.genre}
          </div>
        ))}
      </div>

    </div>
  );
}
