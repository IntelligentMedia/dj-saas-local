
AI LINEUP SCHEDULER ENGINE

Features:
- AI generated DJ timetable
- Genre-based scheduling
- Designed for global DJ automation
