
AVATAR CROWD SYNC SYSTEM

Features:
- Avatar reacts to music + crowd energy
- Color shifts based on crowd intensity
- AI crowd sync simulation backend
