
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());

function randomInt(min,max){
  return Math.floor(Math.random()*(max-min+1))+min;
}

// Simulated crowd energy
app.get("/crowd",(req,res)=>{
  res.json({energy: randomInt(10,100)});
});

app.listen(4000,()=>console.log("Avatar Crowd Sync API running"));
