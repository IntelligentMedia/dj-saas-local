
import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);
  const audioRef = useRef(null);
  const [crowd,setCrowd] = useState(0);

  useEffect(()=>{

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true, alpha:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 🤖 Avatar
    const material = new THREE.MeshBasicMaterial({color:0x00f0ff, wireframe:true});

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.6,16,16), material);
    head.position.y = 2.5;

    const body = new THREE.Mesh(new THREE.BoxGeometry(1.2,2,0.6), material);
    body.position.y = 1;

    const leftArm = new THREE.Mesh(new THREE.BoxGeometry(0.4,1.5,0.4), material);
    leftArm.position.set(-1,1.5,0);

    const rightArm = new THREE.Mesh(new THREE.BoxGeometry(0.4,1.5,0.4), material);
    rightArm.position.set(1,1.5,0);

    const avatar = new THREE.Group();
    avatar.add(head);
    avatar.add(body);
    avatar.add(leftArm);
    avatar.add(rightArm);
    scene.add(avatar);

    camera.position.z = 8;

    // 🔊 Audio analyser
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    const audio = audioRef.current;
    const source = ctx.createMediaElementSource(audio);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;

    source.connect(analyser).connect(ctx.destination);
    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    function animate(){
      requestAnimationFrame(animate);

      analyser.getByteFrequencyData(dataArray);

      let sum=0;
      for(let i=0;i<dataArray.length;i++){
        sum += dataArray[i];
      }
      const avg = sum/dataArray.length;

      // Avatar reacts to BOTH music + crowd energy
      const energy = (avg/255) + (crowd/100);

      avatar.rotation.y += 0.01 * energy;
      avatar.position.y = Math.sin(Date.now()*0.002)*energy;

      leftArm.rotation.z = Math.sin(Date.now()*0.005)*energy;
      rightArm.rotation.z = -Math.sin(Date.now()*0.005)*energy;

      // Crowd color shift
      const color = new THREE.Color().setHSL(0.5-energy*0.2,1,0.5);
      material.color = color;

      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[crowd]);

  // 🤖 Fetch crowd energy from backend
  useEffect(()=>{
    const interval = setInterval(async()=>{
      const res = await fetch("http://localhost:4000/crowd");
      const json = await res.json();
      setCrowd(json.energy);
    },2000);

    return ()=>clearInterval(interval);
  },[]);

  return(
    <div style={{background:"#02040a",height:"100vh"}}>
      <h1 style={{position:"absolute",color:"#00f0ff",padding:15,textShadow:"0 0 10px #00f0ff"}}>
        🤖 Avatar Crowd Sync System
      </h1>

      <audio ref={audioRef} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"/>

      <div style={{position:"absolute",top:70,left:20,color:"#fff"}}>
        <button onClick={()=>audioRef.current.play()}>Play Music</button>
        <br/>
        Crowd Energy: {crowd}
      </div>

      <div ref={mountRef}></div>
    </div>
  );
}
