
REAL STREAM LOCK ENGINE VERSION

Stream only allowed when:
- DJ approved
- Session active
- Activation code valid time

Login:
dj1 / 1234

Setup:
1) Import xampp_schema.sql into phpMyAdmin
2) cd api -> npm install -> npm start
3) cd frontend -> npm install -> npm run dev
