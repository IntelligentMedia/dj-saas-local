
GESTURE CONTROL MIXER SYSTEM

Features:
- Mouse gesture crossfader
- 3D holographic slider
- Real-time position tracking
- Foundation for hand-tracking upgrades
