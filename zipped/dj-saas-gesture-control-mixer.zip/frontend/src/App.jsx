
import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);
  const [cross,setCross] = useState(0.5);

  useEffect(()=>{

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true, alpha:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 🎚️ Crossfader bar
    const geo = new THREE.BoxGeometry(6,0.2,0.2);
    const mat = new THREE.MeshBasicMaterial({color:0x00f0ff, wireframe:true});
    const bar = new THREE.Mesh(geo,mat);
    scene.add(bar);

    // 🔵 Knob
    const knobGeo = new THREE.SphereGeometry(0.3,16,16);
    const knobMat = new THREE.MeshBasicMaterial({color:0xff00ff, wireframe:true});
    const knob = new THREE.Mesh(knobGeo,knobMat);
    knob.position.x = 0;
    scene.add(knob);

    camera.position.z = 8;

    function animate(){
      requestAnimationFrame(animate);
      renderer.render(scene,camera);
    }

    animate();

    // 🖱️ Gesture (mouse drag) control
    let dragging=false;

    function onDown(){ dragging=true; }
    function onUp(){ dragging=false; }

    function onMove(e){
      if(!dragging) return;

      const x = (e.clientX/window.innerWidth)*2-1;
      const clamped = Math.max(-1,Math.min(1,x));
      knob.position.x = clamped*3;
      setCross((clamped+1)/2);
    }

    window.addEventListener("mousedown",onDown);
    window.addEventListener("mouseup",onUp);
    window.addEventListener("mousemove",onMove);

    return ()=>{
      window.removeEventListener("mousedown",onDown);
      window.removeEventListener("mouseup",onUp);
      window.removeEventListener("mousemove",onMove);
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#02040a",height:"100vh"}}>
      <h1 style={{position:"absolute",color:"#00f0ff",padding:15,textShadow:"0 0 10px #00f0ff"}}>
        ✋ Gesture Control Mixer System
      </h1>

      <div style={{position:"absolute",top:60,left:20,color:"#fff"}}>
        Crossfader Position: {cross.toFixed(2)}
        <br/>
        (Drag mouse left/right to control)
      </div>

      <div ref={mountRef}></div>
    </div>
  );
}
