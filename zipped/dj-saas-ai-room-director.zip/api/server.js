
const express = require("express");
const cors = require("cors");
const { AccessToken } = require("livekit-server-sdk");

const app = express();
app.use(cors());
app.use(express.json());

const LIVEKIT_API_KEY="devkey";
const LIVEKIT_API_SECRET="secret";

// 🤖 AI Genre → Room Mapping (simple rule engine)
function chooseRoom(genre){

  if(genre==="house") return "house-room";
  if(genre==="techno") return "techno-room";
  if(genre==="lounge") return "lounge-room";
  if(genre==="afro") return "afro-room";

  return "global-room";
}

app.get("/ai-room",(req,res)=>{

  const genre = req.query.genre || "house";

  const room = chooseRoom(genre);

  res.json({room});
});

// Token generator
app.get("/token",(req,res)=>{

  const room = req.query.room || "global-room";

  const at = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
    identity: "listener-"+Math.floor(Math.random()*9999)
  });

  at.addGrant({
    roomJoin:true,
    room:room,
    canPublish:false,
    canSubscribe:true
  });

  res.json({token: at.toJwt()});
});

app.listen(4000,()=>console.log("AI Room Director API running"));
