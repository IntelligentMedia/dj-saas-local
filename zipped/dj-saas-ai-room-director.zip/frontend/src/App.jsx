
import React, { useState } from "react";
import { connect } from "livekit-client";

export default function App(){

  const [genre,setGenre] = useState("house");
  const [status,setStatus] = useState("Idle");

  const autoJoin = async ()=>{

    try{

      // Ask backend AI which room to join
      const ai = await fetch("http://localhost:4000/ai-room?genre="+genre);
      const aiData = await ai.json();

      const tokenRes = await fetch("http://localhost:4000/token?room="+aiData.room);
      const tokenData = await tokenRes.json();

      const room = await connect("ws://localhost:7880", tokenData.token);

      setStatus("🎧 Connected to "+aiData.room+" (AI Selected)");

      room.on("trackSubscribed",(track)=>{
        const el = track.attach();
        el.autoplay = true;
        document.body.appendChild(el);
      });

    }catch(e){
      console.error(e);
      setStatus("Connection Failed");
    }
  };

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🤖 AI Room Director</h1>

      <div>
        Pub Genre:
        <select value={genre} onChange={e=>setGenre(e.target.value)} style={{marginLeft:10}}>
          <option value="house">House</option>
          <option value="techno">Techno</option>
          <option value="lounge">Lounge</option>
          <option value="afro">Afro</option>
        </select>
      </div>

      <button style={{marginTop:20}} onClick={autoJoin}>
        Auto Join DJ (AI Routing)
      </button>

      <h3>Status: {status}</h3>

    </div>
  );
}
