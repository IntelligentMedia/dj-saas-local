
AI ROOM DIRECTOR SYSTEM

Features:
- Genre-based AI room routing
- Auto DJ selection
- Pub auto-switching between DJ rooms

Run:
1) livekit-server --dev
2) cd api && npm install && npm start
3) cd frontend && npm install && npm run dev
