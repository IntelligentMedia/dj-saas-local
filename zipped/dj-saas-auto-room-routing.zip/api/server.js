
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { AccessToken } = require("livekit-server-sdk");

const app = express();
app.use(cors());
app.use(express.json());

const LIVEKIT_API_KEY="devkey";
const LIVEKIT_API_SECRET="secret";
const AUTH_SECRET="AUTO_ROOM_SECRET";

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=?",[username],async(err,rows)=>{
    if(!rows || rows.length===0) return res.status(401).send("Invalid");

    const user=rows[0];
    const match = await bcrypt.compare(password,user.password);
    if(!match) return res.status(401).send("Invalid");

    const token = jwt.sign({
      id:user.id,
      role:user.role,
      approved:user.approved
    },AUTH_SECRET,{expiresIn:"2h"});

    res.json({accessToken:token,user:{username:user.username,role:user.role}});
  });
});

// 🔥 AUTO ROOM ROUTING ENGINE
app.get("/auto-room-token",auth,(req,res)=>{

  // Find active booking for this user/pub/dj
  db.query("SELECT * FROM bookings WHERE active=1 LIMIT 1",(err,bookings)=>{

    if(!bookings || bookings.length===0)
      return res.send("DENIED: NO ACTIVE BOOKING");

    const booking = bookings[0];

    // Automatically decide room name
    const roomName = "dj-"+booking.dj_id+"-pub-"+booking.pub_id;

    // Check activation window
    db.query("SELECT * FROM activation_codes",(err,codes)=>{

      const now = new Date();
      const valid = codes.find(c=>{
        return now>=new Date(c.start_time) && now<=new Date(c.end_time);
      });

      if(!valid) return res.send("DENIED: OUTSIDE TIME WINDOW");

      // Generate LiveKit token automatically routed
      const at = new AccessToken(LIVEKIT_API_KEY,LIVEKIT_API_SECRET,{
        identity:"user-"+req.user.id
      });

      at.addGrant({
        roomJoin:true,
        room:roomName,
        canPublish:req.user.role==="dj",
        canSubscribe:true
      });

      res.send("ROOM: "+roomName+" | TOKEN: "+at.toJwt());
    });

  });

});

app.listen(4000,()=>console.log("Auto Room Routing API running"));
