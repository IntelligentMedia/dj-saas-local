
AUTO ROOM ROUTING ENGINE

System automatically assigns LiveKit room based on booking.

Run LiveKit:
docker run --rm -p 7880:7880 -p 7881:7881 -e LIVEKIT_KEYS="devkey:secret" livekit/livekit-server

Login:
dj1 / 1234
pub1 / 1234
