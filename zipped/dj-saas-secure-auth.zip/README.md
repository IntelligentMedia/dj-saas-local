
SECURE PRODUCTION AUTH VERSION

PASSWORD FOR ALL USERS:
1234

Features:
- bcrypt password hashing
- JWT tokens
- Protected admin routes
- Role-based authorization

Steps:
1) Import xampp_schema.sql into phpMyAdmin
2) cd api -> npm install -> npm start
3) cd frontend -> npm install -> npm run dev
