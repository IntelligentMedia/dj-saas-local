
import React, { useState } from "react";

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [users,setUsers]=useState([]);
  const [token,setToken]=useState(localStorage.getItem("token"));

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const data=await res.json();
      setUser(data.user);
      setToken(data.token);
      localStorage.setItem("token",data.token);
      if(data.user.role==="admin") loadUsers(data.token);
    }else alert("Login failed");
  };

  const loadUsers=async(tok)=>{
    const res=await fetch("http://localhost:4000/admin/users",{
      headers:{Authorization:"Bearer "+tok}
    });
    if(res.ok){
      const data=await res.json();
      setUsers(data);
    }else alert("Not authorized");
  };

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Secure Login</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return(
    <div style={{padding:20}}>
      <h1>Welcome {user.username} ({user.role})</h1>

      {user.role==="admin" && (
        <div>
          <h2>Admin Dashboard (Protected)</h2>
          <button onClick={()=>loadUsers(token)}>Load Users</button>
          {users.map(u=>(<div key={u.id}>{u.username} - {u.role}</div>))}
        </div>
      )}

      {user.role==="dj" && <div>DJ Panel Ready</div>}
      {user.role==="pub" && <div>Pub Panel Ready</div>}
    </div>
  );
}
