
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const app = express();
app.use(cors());
app.use(express.json());

const SECRET="SUPER_SECURE_SECRET";

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

// JWT MIDDLEWARE
function auth(req,res,next){
  const header = req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token = header.split(" ")[1];
  try{
    req.user = jwt.verify(token,SECRET);
    next();
  }catch{
    res.sendStatus(403);
  }
}

// ADMIN CHECK
function adminOnly(req,res,next){
  if(req.user.role!=="admin") return res.sendStatus(403);
  next();
}

// LOGIN WITH HASHED PASSWORD
app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=?",[username],async(err,rows)=>{
    if(!rows || rows.length===0) return res.status(401).send("Invalid");

    const user = rows[0];
    const match = await bcrypt.compare(password,user.password);
    if(!match) return res.status(401).send("Invalid");

    const token = jwt.sign({id:user.id,role:user.role},SECRET,{expiresIn:"2h"});
    res.json({token,user:{username:user.username,role:user.role}});
  });
});

// PROTECTED ADMIN ROUTE
app.get("/admin/users",auth,adminOnly,(req,res)=>{
  db.query("SELECT id,username,role FROM users",(err,rows)=>{
    res.json(rows);
  });
});

app.listen(4000,()=>console.log("Secure API running 4000"));
