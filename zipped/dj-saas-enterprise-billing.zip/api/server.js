
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="ENTERPRISE_BILLING_SECRET";

// Demo booking sessions with hours
let BOOKINGS = [
  {pub:"Pub Beirut", dj:"DJ Sam", hours:2, rate:50},
  {pub:"Pub Paris", dj:"DJ Alex", hours:3, rate:60},
  {pub:"Pub Dubai", dj:"DJ Lina", hours:1, rate:70}
];

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

// Demo login
app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  if(password!=="1234") return res.status(401).send("Invalid");

  const role = username.startsWith("dj") ? "dj":"pub";

  const token = jwt.sign({id:1,role},AUTH_SECRET,{expiresIn:"2h"});
  res.json({accessToken:token,user:{username,role}});
});

// 💳 ENTERPRISE BILLING ENGINE
app.get("/run-billing",auth,(req,res)=>{

  let totalPlatformRevenue = 0;
  let output = "ENTERPRISE BILLING REPORT\\n\\n";

  BOOKINGS.forEach(b=>{
    const total = b.hours * b.rate;
    const platformFee = total * 0.20;
    const djEarn = total - platformFee;

    totalPlatformRevenue += platformFee;

    output += "Pub: "+b.pub+"\\n";
    output += "DJ: "+b.dj+"\\n";
    output += "Hours: "+b.hours+"\\n";
    output += "Session Total: $"+total+"\\n";
    output += "DJ Earns: $"+djEarn+"\\n";
    output += "Platform Fee: $"+platformFee+"\\n";
    output += "---------------------------\\n";
  });

  output += "\\nTOTAL PLATFORM REVENUE: $"+totalPlatformRevenue;

  res.send(output);
});

app.listen(4000,()=>console.log("Enterprise Billing API running"));
