
ENTERPRISE BILLING ENGINE

Features:
- Hourly DJ billing
- Platform commission
- Pub subscription model
- Session revenue calculation

Login:
dj1 / 1234
pub1 / 1234
