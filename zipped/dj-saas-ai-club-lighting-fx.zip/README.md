
AI CLUB LIGHTING FX SYSTEM

Features:
- Beat reactive club lights
- AI color shifting stage lights
- Rotating laser beams
- WebAudio energy driven effects
