
import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);
  const audioRef = useRef(null);

  useEffect(()=>{

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 🎧 Stage floor
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(20,20),
      new THREE.MeshBasicMaterial({wireframe:true})
    );
    floor.rotation.x = -Math.PI/2;
    scene.add(floor);

    // 💡 Club Lights
    const lights = [];
    for(let i=0;i<6;i++){
      const light = new THREE.PointLight(0x00f0ff,1,20);
      light.position.set(Math.sin(i)*5,3,Math.cos(i)*5);
      scene.add(light);
      lights.push(light);
    }

    // 🌈 Laser beams
    const lasers = [];
    const laserMat = new THREE.LineBasicMaterial();
    for(let i=0;i<4;i++){
      const points = [];
      points.push(new THREE.Vector3(0,3,0));
      points.push(new THREE.Vector3((Math.random()-0.5)*10,0,(Math.random()-0.5)*10));
      const geo = new THREE.BufferGeometry().setFromPoints(points);
      const line = new THREE.Line(geo,laserMat);
      scene.add(line);
      lasers.push(line);
    }

    camera.position.set(0,6,10);
    camera.lookAt(0,0,0);

    // 🔊 WebAudio analyser
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    const audio = audioRef.current;
    const source = ctx.createMediaElementSource(audio);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser).connect(ctx.destination);
    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    function animate(){
      requestAnimationFrame(animate);

      analyser.getByteFrequencyData(dataArray);

      let sum=0;
      for(let i=0;i<dataArray.length;i++){
        sum+=dataArray[i];
      }
      const energy = sum/dataArray.length/255;

      // 🤖 AI Light reaction
      lights.forEach((l,i)=>{
        l.intensity = 1 + energy*3;
        l.color.setHSL((Date.now()*0.0002+i*0.1)%1,1,0.5);
      });

      // 🌈 Laser rotation
      lasers.forEach((laser,i)=>{
        laser.rotation.y += 0.02 + energy*0.05;
      });

      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#000"}}>
      <h1 style={{position:"absolute",color:"#00f0ff",padding:15}}>
        🌈 AI Club Lighting FX System
      </h1>

      <audio
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      />

      <div style={{position:"absolute",top:60,left:20,color:"#fff"}}>
        <button onClick={()=>audioRef.current.play()}>Play Music</button>
      </div>

      <div ref={mountRef}></div>
    </div>
  );
}
