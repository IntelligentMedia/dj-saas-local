
PRO BPM SYNC + EQ ENGINE

Features:
- Dual deck mixer
- Real EQ filters (low/mid/high)
- Crossfader
- Simulated BPM Sync
