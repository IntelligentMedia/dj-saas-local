
import React, { useEffect, useRef, useState } from "react";

export default function App(){

  const ctxRef = useRef(null);

  const audioARef = useRef(null);
  const audioBRef = useRef(null);

  const gainARef = useRef(null);
  const gainBRef = useRef(null);

  const eqLowA = useRef(null);
  const eqMidA = useRef(null);
  const eqHighA = useRef(null);

  const eqLowB = useRef(null);
  const eqMidB = useRef(null);
  const eqHighB = useRef(null);

  const [cross,setCross] = useState(50);

  useEffect(()=>{

    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    ctxRef.current = ctx;

    const setupDeck = (audioEl, refs)=>{

      const src = ctx.createMediaElementSource(audioEl);

      const low = ctx.createBiquadFilter();
      low.type="lowshelf";
      low.frequency.value=200;

      const mid = ctx.createBiquadFilter();
      mid.type="peaking";
      mid.frequency.value=1000;

      const high = ctx.createBiquadFilter();
      high.type="highshelf";
      high.frequency.value=3000;

      const gain = ctx.createGain();
      gain.gain.value=0.5;

      src.connect(low).connect(mid).connect(high).connect(gain).connect(ctx.destination);

      refs.low.current=low;
      refs.mid.current=mid;
      refs.high.current=high;
      refs.gain.current=gain;
    };

    setupDeck(audioARef.current,{low:eqLowA,mid:eqMidA,high:eqHighA,gain:gainARef});
    setupDeck(audioBRef.current,{low:eqLowB,mid:eqMidB,high:eqHighB,gain:gainBRef});

  },[]);

  const updateCross = (v)=>{
    setCross(v);
    if(!gainARef.current || !gainBRef.current) return;
    gainARef.current.gain.value = 1 - v/100;
    gainBRef.current.gain.value = v/100;
  };

  const changeEQ=(ref,val)=>{
    if(ref.current) ref.current.gain.value = parseFloat(val);
  };

  // Simple BPM sync simulation
  const syncBPM=()=>{
    if(!audioARef.current || !audioBRef.current) return;
    audioBRef.current.playbackRate = audioARef.current.playbackRate;
  };

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🎛️ Pro BPM Sync + EQ DJ Engine</h1>

      <div style={{display:"flex",gap:40}}>

        <div>
          <h3>Deck A</h3>
          <audio ref={audioARef} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"/>
          <button onClick={()=>audioARef.current.play()}>Play</button>
          <button onClick={()=>audioARef.current.pause()}>Pause</button>

          <div>EQ</div>
          Low <input type="range" min="-20" max="20" defaultValue="0"
            onChange={e=>changeEQ(eqLowA,e.target.value)}/>
          Mid <input type="range" min="-20" max="20" defaultValue="0"
            onChange={e=>changeEQ(eqMidA,e.target.value)}/>
          High <input type="range" min="-20" max="20" defaultValue="0"
            onChange={e=>changeEQ(eqHighA,e.target.value)}/>
        </div>

        <div>
          <h3>Deck B</h3>
          <audio ref={audioBRef} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"/>
          <button onClick={()=>audioBRef.current.play()}>Play</button>
          <button onClick={()=>audioBRef.current.pause()}>Pause</button>

          <div>EQ</div>
          Low <input type="range" min="-20" max="20" defaultValue="0"
            onChange={e=>changeEQ(eqLowB,e.target.value)}/>
          Mid <input type="range" min="-20" max="20" defaultValue="0"
            onChange={e=>changeEQ(eqMidB,e.target.value)}/>
          High <input type="range" min="-20" max="20" defaultValue="0"
            onChange={e=>changeEQ(eqHighB,e.target.value)}/>
        </div>

      </div>

      <div style={{marginTop:30,width:400}}>
        <h3>Crossfader</h3>
        <input type="range" min="0" max="100" value={cross}
          onChange={e=>updateCross(e.target.value)}
          style={{width:"100%"}}/>
      </div>

      <div style={{marginTop:20}}>
        <button onClick={syncBPM}>🔄 Sync BPM (Simulated)</button>
      </div>

    </div>
  );
}
