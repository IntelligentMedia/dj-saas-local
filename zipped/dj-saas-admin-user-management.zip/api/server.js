
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const app = express();
app.use(cors());
app.use(express.json());

const ACCESS_SECRET="ACCESS_SECRET_KEY";
const REFRESH_SECRET="REFRESH_SECRET_KEY";

let refreshTokens = [];

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

function auth(req,res,next){
  const header = req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token = header.split(" ")[1];
  jwt.verify(token,ACCESS_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

function adminOnly(req,res,next){
  if(req.user.role!=="admin") return res.sendStatus(403);
  next();
}

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=?",[username],async(err,rows)=>{
    if(!rows || rows.length===0) return res.status(401).send("Invalid");

    const user = rows[0];
    const match = await bcrypt.compare(password,user.password);
    if(!match) return res.status(401).send("Invalid");

    const accessToken = jwt.sign({id:user.id,role:user.role},ACCESS_SECRET,{expiresIn:"1h"});
    const refreshToken = jwt.sign({id:user.id,role:user.role},REFRESH_SECRET);
    refreshTokens.push(refreshToken);

    res.json({
      accessToken,
      refreshToken,
      user:{username:user.username,role:user.role}
    });
  });
});

app.get("/admin/users",auth,adminOnly,(req,res)=>{
  db.query("SELECT id,username,role FROM users",(err,rows)=>{
    res.json(rows);
  });
});

app.post("/admin/create-user",auth,adminOnly,async(req,res)=>{
  const {username,password,role}=req.body;
  const hash = await bcrypt.hash(password,10);
  db.query("INSERT INTO users(username,password,role) VALUES(?,?,?)",[username,hash,role]);
  res.json({ok:true});
});

app.delete("/admin/delete-user/:id",auth,adminOnly,(req,res)=>{
  db.query("DELETE FROM users WHERE id=?",[req.params.id]);
  res.json({ok:true});
});

app.listen(4000,()=>console.log("Admin User Management API running"));
