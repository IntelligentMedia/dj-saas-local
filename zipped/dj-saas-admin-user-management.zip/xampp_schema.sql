
CREATE DATABASE IF NOT EXISTS dj_saas;
USE dj_saas;

CREATE TABLE users(
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50),
 password VARCHAR(255),
 role VARCHAR(10)
);

INSERT INTO users(username,password,role) VALUES
('admin','$2a$10$Wl9v1zjK8c6Y0kzY0q2y8u1zYw9hFzGx7Y0ZzF0Qb1c1ZQk9bV3kW','admin');
