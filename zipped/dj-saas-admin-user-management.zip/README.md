
ADMIN USER MANAGEMENT VERSION

Login:
admin / 1234

Features:
- Create DJ / Pub / Admin users
- Delete users
- bcrypt password hashing
- JWT protected admin routes

Setup:
1) Import xampp_schema.sql into phpMyAdmin
2) cd api -> npm install -> npm start
3) cd frontend -> npm install -> npm run dev
