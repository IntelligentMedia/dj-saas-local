
import React, { useState } from "react";

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [users,setUsers]=useState([]);

  const [newUser,setNewUser]=useState("");
  const [newPass,setNewPass]=useState("");
  const [newRole,setNewRole]=useState("dj");

  const getToken=()=>localStorage.getItem("accessToken");

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const data=await res.json();
      localStorage.setItem("accessToken",data.accessToken);
      localStorage.setItem("refreshToken",data.refreshToken);
      setUser(data.user);
      if(data.user.role==="admin") loadUsers();
    }else alert("Login failed");
  };

  const loadUsers=async()=>{
    const res=await fetch("http://localhost:4000/admin/users",{
      headers:{Authorization:"Bearer "+getToken()}
    });
    const data=await res.json();
    setUsers(data);
  };

  const createUser=async()=>{
    await fetch("http://localhost:4000/admin/create-user",{
      method:"POST",
      headers:{
        "Content-Type":"application/json",
        Authorization:"Bearer "+getToken()
      },
      body:JSON.stringify({
        username:newUser,
        password:newPass,
        role:newRole
      })
    });
    loadUsers();
  };

  const deleteUser=async(id)=>{
    await fetch("http://localhost:4000/admin/delete-user/"+id,{
      method:"DELETE",
      headers:{Authorization:"Bearer "+getToken()}
    });
    loadUsers();
  };

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Admin User Management Login</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return(
    <div style={{padding:20}}>
      <h1>Welcome {user.username} ({user.role})</h1>

      {user.role==="admin" && (
        <div>
          <h2>Admin Dashboard</h2>

          <h3>Create User</h3>
          <input placeholder="username" onChange={e=>setNewUser(e.target.value)}/>
          <input placeholder="password" onChange={e=>setNewPass(e.target.value)}/>
          <select onChange={e=>setNewRole(e.target.value)}>
            <option value="dj">DJ</option>
            <option value="pub">PUB</option>
            <option value="admin">ADMIN</option>
          </select>
          <button onClick={createUser}>Create</button>

          <h3>User List</h3>
          {users.map(u=>(
            <div key={u.id}>
              {u.username} - {u.role}
              <button onClick={()=>deleteUser(u.id)}>Delete</button>
            </div>
          ))}
        </div>
      )}

      {user.role==="dj" && <div>DJ Panel Ready</div>}
      {user.role==="pub" && <div>Pub Panel Ready</div>}
    </div>
  );
}
