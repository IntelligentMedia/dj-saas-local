
import React, { useState } from "react";

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [users,setUsers]=useState([]);

  const getAccessToken = ()=>localStorage.getItem("accessToken");

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const data=await res.json();
      localStorage.setItem("accessToken",data.accessToken);
      localStorage.setItem("refreshToken",data.refreshToken);
      setUser(data.user);
      if(data.user.role==="admin") loadUsers();
    }else alert("Login failed");
  };

  const refreshToken=async()=>{
    const token = localStorage.getItem("refreshToken");
    const res = await fetch("http://localhost:4000/token",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({token})
    });

    if(res.ok){
      const data = await res.json();
      localStorage.setItem("accessToken",data.accessToken);
      return data.accessToken;
    }else{
      alert("Session expired");
    }
  };

  const loadUsers=async()=>{
    let token = getAccessToken();

    let res = await fetch("http://localhost:4000/admin/users",{
      headers:{Authorization:"Bearer "+token}
    });

    if(res.status===403){
      token = await refreshToken();
      res = await fetch("http://localhost:4000/admin/users",{
        headers:{Authorization:"Bearer "+token}
      });
    }

    if(res.ok){
      const data = await res.json();
      setUsers(data);
    }
  };

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Secure Login (Refresh Tokens)</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return(
    <div style={{padding:20}}>
      <h1>Welcome {user.username} ({user.role})</h1>

      {user.role==="admin" && (
        <div>
          <h2>Admin Dashboard</h2>
          <button onClick={loadUsers}>Load Users</button>
          {users.map(u=>(<div key={u.id}>{u.username} - {u.role}</div>))}
        </div>
      )}

      {user.role==="dj" && <div>DJ Panel Ready</div>}
      {user.role==="pub" && <div>Pub Panel Ready</div>}
    </div>
  );
}
