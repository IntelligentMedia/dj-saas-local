
CREATE DATABASE IF NOT EXISTS dj_saas;
USE dj_saas;

CREATE TABLE users(
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50),
 password VARCHAR(255),
 role VARCHAR(10),
 approved BOOLEAN DEFAULT 1
);

CREATE TABLE sessions(
 id INT AUTO_INCREMENT PRIMARY KEY,
 booking_id INT,
 active BOOLEAN DEFAULT 1
);

CREATE TABLE activation_codes(
 id INT AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(50),
 start_time DATETIME,
 end_time DATETIME
);

INSERT INTO users(username,password,role,approved) VALUES
('dj1','$2a$10$Wl9v1zjK8c6Y0kzY0q2y8u1zYw9hFzGx7Y0ZzF0Qb1c1ZQk9bV3kW','dj',1);

INSERT INTO sessions(booking_id,active) VALUES(1,1);

INSERT INTO activation_codes(code,start_time,end_time) VALUES
('PUB-555',NOW(),DATE_ADD(NOW(),INTERVAL 1 HOUR));
