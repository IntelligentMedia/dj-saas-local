
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const app = express();
app.use(cors());
app.use(express.json());

const SECRET="WEBRTC_GATEKEEPER_SECRET";

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=?",[username],async(err,rows)=>{
    if(!rows || rows.length===0) return res.status(401).send("Invalid");

    const user=rows[0];
    const match = await bcrypt.compare(password,user.password);
    if(!match) return res.status(401).send("Invalid");

    const token = jwt.sign({
      id:user.id,
      role:user.role,
      approved:user.approved
    },SECRET,{expiresIn:"2h"});

    res.json({accessToken:token,user:{username:user.username,role:user.role}});
  });
});

// WEBRTC TOKEN GATEKEEPER ENGINE
app.get("/webrtc-token",auth,(req,res)=>{

  // Rule 1: DJ must be approved
  if(req.user.role==="dj" && !req.user.approved){
    return res.send("DENIED: DJ NOT APPROVED");
  }

  // Rule 2: Session must be active
  db.query("SELECT * FROM sessions WHERE active=1",(err,sessions)=>{

    if(!sessions || sessions.length===0)
      return res.send("DENIED: NO ACTIVE SESSION");

    // Rule 3: Activation code valid
    db.query("SELECT * FROM activation_codes",(err,codes)=>{

      const now = new Date();
      const valid = codes.find(c=>{
        return now>=new Date(c.start_time) && now<=new Date(c.end_time);
      });

      if(!valid) return res.send("DENIED: NO VALID ACTIVATION");

      // If all OK -> generate WebRTC access token
      const webrtcToken = jwt.sign({
        uid:req.user.id,
        scope:"stream_access"
      },SECRET,{expiresIn:"60s"});

      res.send("WEBRTC TOKEN: "+webrtcToken);
    });

  });

});

app.listen(4000,()=>console.log("WebRTC Gatekeeper API running"));
