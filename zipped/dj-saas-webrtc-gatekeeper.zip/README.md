
WEBRTC TOKEN GATEKEEPER VERSION

System generates short-lived WebRTC tokens ONLY when:
- DJ approved
- Session active
- Activation time valid

Login:
dj1 / 1234

Setup:
1) Import xampp_schema.sql into phpMyAdmin
2) cd api -> npm install -> npm start
3) cd frontend -> npm install -> npm run dev
