
LIVEKIT REAL STREAMING INTEGRATION

This version generates REAL LiveKit tokens.

IMPORTANT:
Install and run LiveKit locally:

docker run --rm -p 7880:7880 -p 7881:7881 -e LIVEKIT_KEYS="devkey:secret" livekit/livekit-server

Login:
dj1 / 1234

Setup:
1) Import xampp_schema.sql into phpMyAdmin
2) cd api -> npm install -> npm start
3) cd frontend -> npm install -> npm run dev
