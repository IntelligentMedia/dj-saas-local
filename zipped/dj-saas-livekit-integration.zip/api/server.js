
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

// LiveKit server SDK
const { AccessToken } = require("livekit-server-sdk");

const app = express();
app.use(cors());
app.use(express.json());

// 🔐 CHANGE THESE FOR REAL LIVEKIT SERVER
const LIVEKIT_API_KEY="devkey";
const LIVEKIT_API_SECRET="secret";

const AUTH_SECRET="LIVEKIT_AUTH_SECRET";

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=?",[username],async(err,rows)=>{
    if(!rows || rows.length===0) return res.status(401).send("Invalid");

    const user=rows[0];
    const match = await bcrypt.compare(password,user.password);
    if(!match) return res.status(401).send("Invalid");

    const token = jwt.sign({
      id:user.id,
      role:user.role,
      approved:user.approved
    },AUTH_SECRET,{expiresIn:"2h"});

    res.json({accessToken:token,user:{username:user.username,role:user.role}});
  });
});

// 🎧 LIVEKIT TOKEN GATEKEEPER
app.get("/livekit-token",auth,async(req,res)=>{

  // Check session active
  db.query("SELECT * FROM sessions WHERE active=1",(err,sessions)=>{

    if(!sessions || sessions.length===0)
      return res.send("DENIED: NO ACTIVE SESSION");

    // Check activation time
    db.query("SELECT * FROM activation_codes",(err,codes)=>{

      const now = new Date();
      const valid = codes.find(c=>{
        return now>=new Date(c.start_time) && now<=new Date(c.end_time);
      });

      if(!valid) return res.send("DENIED: OUTSIDE TIME WINDOW");

      // Generate REAL LiveKit token
      const at = new AccessToken(LIVEKIT_API_KEY,LIVEKIT_API_SECRET,{
        identity: "user-"+req.user.id
      });

      at.addGrant({
        roomJoin: true,
        room: "dj-room",
        canPublish: req.user.role==="dj",
        canSubscribe: true
      });

      const token = at.toJwt();
      res.send(token);
    });

  });
});

app.listen(4000,()=>console.log("LiveKit Integration API running"));
