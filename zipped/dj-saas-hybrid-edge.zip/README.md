
HYBRID EDGE STREAMING SYSTEM

Logic:
- If pub/DJ near edge node → use EDGE relay (lower latency, cheaper)
- Otherwise → fallback to CLOUD node

Login:
dj1 / 1234
pub1 / 1234
