
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="HYBRID_EDGE_SECRET";

// Core cloud nodes
const CLOUD_NODES = [
  {url:"wss://cloud-node-1"},
  {url:"wss://cloud-node-2"}
];

// Edge relay nodes (near pubs / DJs)
const EDGE_NODES = [
  {url:"ws://edge-beirut", lat:33.8938, lng:35.5018},
  {url:"ws://edge-paris", lat:48.8566, lng:2.3522}
];

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

// Demo login
app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  if(password!=="1234") return res.status(401).send("Invalid");

  const role = username.startsWith("dj") ? "dj":"pub";

  const token = jwt.sign({id:1,role},AUTH_SECRET,{expiresIn:"2h"});
  res.json({accessToken:token,user:{username,role}});
});

// distance check
function distance(a,b){
  return Math.sqrt(Math.pow(a.lat-b.lat,2)+Math.pow(a.lng-b.lng,2));
}

// 🔥 HYBRID EDGE ROUTING
app.get("/edge-route",auth,(req,res)=>{

  const lat = parseFloat(req.query.lat || "0");
  const lng = parseFloat(req.query.lng || "0");

  // find nearest edge node
  let bestEdge = EDGE_NODES[0];
  let bestDist = distance({lat,lng},bestEdge);

  EDGE_NODES.forEach(n=>{
    const d = distance({lat,lng},n);
    if(d < bestDist){
      bestEdge = n;
      bestDist = d;
    }
  });

  let message = "";

  if(bestDist < 5){ // close to edge node
    message += "EDGE MODE ACTIVE\\n";
    message += "Connected to edge relay: "+bestEdge.url+"\\n";
    message += "Cloud fallback available.";
  }else{
    const cloud = CLOUD_NODES[Math.floor(Math.random()*CLOUD_NODES.length)];
    message += "CLOUD MODE\\n";
    message += "Connected to cloud node: "+cloud.url;
  }

  res.send(message);
});

app.listen(4000,()=>console.log("Hybrid Edge Streaming API running"));
