
import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { Hands } from "@mediapipe/hands";
import { Camera } from "@mediapipe/camera_utils";

export default function App(){

  const mountRef = useRef(null);
  const videoRef = useRef(null);
  const [cross,setCross] = useState(0.5);

  useEffect(()=>{

    // 🎛️ Three.js Scene
    const scene = new THREE.Scene();
    const camera3d = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true, alpha:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    const barGeo = new THREE.BoxGeometry(6,0.2,0.2);
    const barMat = new THREE.MeshBasicMaterial({color:0x00f0ff, wireframe:true});
    const bar = new THREE.Mesh(barGeo,barMat);
    scene.add(bar);

    const knobGeo = new THREE.SphereGeometry(0.3,16,16);
    const knobMat = new THREE.MeshBasicMaterial({color:0xff00ff, wireframe:true});
    const knob = new THREE.Mesh(knobGeo,knobMat);
    scene.add(knob);

    camera3d.position.z = 8;

    function animate(){
      requestAnimationFrame(animate);
      renderer.render(scene,camera3d);
    }
    animate();

    // ✋ MediaPipe Hands Setup
    const hands = new Hands({
      locateFile: (file) => {
        return `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`;
      }
    });

    hands.setOptions({
      maxNumHands: 1,
      modelComplexity: 1,
      minDetectionConfidence: 0.7,
      minTrackingConfidence: 0.7
    });

    hands.onResults((results)=>{

      if(results.multiHandLandmarks && results.multiHandLandmarks.length>0){
        const hand = results.multiHandLandmarks[0];

        // index finger tip x position (landmark 8)
        const x = hand[8].x; // 0 → 1
        const normalized = (x*2)-1;

        knob.position.x = normalized*3;
        setCross(x);
      }
    });

    const camera = new Camera(videoRef.current,{
      onFrame: async ()=>{
        await hands.send({image:videoRef.current});
      },
      width:640,
      height:480
    });

    camera.start();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#02040a",height:"100vh"}}>

      <h1 style={{position:"absolute",color:"#00f0ff",padding:15,textShadow:"0 0 10px #00f0ff"}}>
        🖐️ Webcam Hand Tracking DJ Control
      </h1>

      <video
        ref={videoRef}
        style={{position:"absolute",top:70,left:20,width:200,border:"2px solid #00f0ff"}}
        autoPlay
        muted
      />

      <div style={{position:"absolute",top:280,left:20,color:"#fff"}}>
        Crossfader Position: {cross.toFixed(2)}
        <br/>
        Move your hand left/right to control
      </div>

      <div ref={mountRef}></div>
    </div>
  );
}
