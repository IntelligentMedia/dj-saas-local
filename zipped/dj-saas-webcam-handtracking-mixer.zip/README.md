
REAL WEBCAM HAND TRACKING CONTROL

Features:
- MediaPipe Hands tracking
- Webcam gesture control
- Move hand to control crossfader
- 3D holographic mixer integration
