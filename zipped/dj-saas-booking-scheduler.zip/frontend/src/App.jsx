
import React, { useState } from "react";

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [bookings,setBookings]=useState([]);
  const [djId,setDjId]=useState("");
  const [hours,setHours]=useState(1);

  const getToken=()=>localStorage.getItem("accessToken");

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const data=await res.json();
      localStorage.setItem("accessToken",data.accessToken);
      setUser(data.user);
      loadBookings(data.accessToken);
    }else alert("Login failed");
  };

  const loadBookings=async(token=getToken())=>{
    const res=await fetch("http://localhost:4000/bookings",{
      headers:{Authorization:"Bearer "+token}
    });
    const data=await res.json();
    setBookings(data);
  };

  const createBooking=async()=>{
    await fetch("http://localhost:4000/bookings",{
      method:"POST",
      headers:{
        "Content-Type":"application/json",
        Authorization:"Bearer "+getToken()
      },
      body:JSON.stringify({djId,hours})
    });
    loadBookings();
  };

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Login</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return(
    <div style={{padding:20}}>
      <h1>Welcome {user.username} ({user.role})</h1>

      {user.role==="pub" && (
        <div>
          <h3>Create Booking</h3>
          <input placeholder="DJ ID" onChange={e=>setDjId(e.target.value)}/>
          <input type="number" value={hours} onChange={e=>setHours(e.target.value)}/>
          <button onClick={createBooking}>Book DJ</button>
        </div>
      )}

      <h3>Bookings</h3>
      {bookings.map(b=>(
        <div key={b.id}>
          DJ:{b.dj_id} | Hours:{b.hours} | Status:{b.status}
        </div>
      ))}
    </div>
  );
}
