
CREATE DATABASE IF NOT EXISTS dj_saas;
USE dj_saas;

CREATE TABLE users(
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50),
 password VARCHAR(255),
 role VARCHAR(10)
);

CREATE TABLE bookings(
 id INT AUTO_INCREMENT PRIMARY KEY,
 dj_id INT,
 pub_id INT,
 hours INT,
 status VARCHAR(20)
);

INSERT INTO users(username,password,role) VALUES
('pub1','$2a$10$Wl9v1zjK8c6Y0kzY0q2y8u1zYw9hFzGx7Y0ZzF0Qb1c1ZQk9bV3kW','pub'),
('dj1','$2a$10$Wl9v1zjK8c6Y0kzY0q2y8u1zYw9hFzGx7Y0ZzF0Qb1c1ZQk9bV3kW','dj');
