
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const app = express();
app.use(cors());
app.use(express.json());

const SECRET="BOOKING_SECRET";

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=?",[username],async(err,rows)=>{
    if(!rows || rows.length===0) return res.status(401).send("Invalid");

    const user=rows[0];
    const match = await bcrypt.compare(password,user.password);
    if(!match) return res.status(401).send("Invalid");

    const token = jwt.sign({id:user.id,role:user.role},SECRET,{expiresIn:"2h"});
    res.json({accessToken:token,user:{username:user.username,role:user.role}});
  });
});

app.get("/bookings",auth,(req,res)=>{
  db.query("SELECT * FROM bookings",(err,rows)=>{
    res.json(rows);
  });
});

app.post("/bookings",auth,(req,res)=>{
  if(req.user.role!=="pub") return res.sendStatus(403);

  const {djId,hours}=req.body;

  db.query("INSERT INTO bookings(dj_id,pub_id,hours,status) VALUES(?,?,?,?)",
    [djId,req.user.id,hours,"pending"]);
  res.json({ok:true});
});

app.listen(4000,()=>console.log("Booking Scheduler API running"));
