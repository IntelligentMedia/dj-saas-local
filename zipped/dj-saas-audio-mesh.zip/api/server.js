
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="AUDIO_MESH_SECRET";

// Simulated pubs acting as edge relays
let PUB_NODES = [
  {id:1, name:"Pub Beirut", capacity:5, connected:2},
  {id:2, name:"Pub Paris", capacity:5, connected:4},
  {id:3, name:"Pub Dubai", capacity:5, connected:1}
];

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

// Demo login
app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  if(password!=="1234") return res.status(401).send("Invalid");

  const role = username.startsWith("dj") ? "dj":"pub";

  const token = jwt.sign({id:1,role},AUTH_SECRET,{expiresIn:"2h"});
  res.json({accessToken:token,user:{username,role}});
});

// 🔥 DISTRIBUTED AUDIO MESH ROUTING
app.get("/mesh-route",auth,(req,res)=>{

  // find pub with lowest load to act as relay
  let relay = PUB_NODES[0];

  PUB_NODES.forEach(p=>{
    const loadA = relay.connected/relay.capacity;
    const loadB = p.connected/p.capacity;
    if(loadB < loadA){
      relay = p;
    }
  });

  relay.connected++;

  let message = "";
  message += "MESH MODE ACTIVE\\n";
  message += "Relay Pub Selected: "+relay.name+"\\n";
  message += "Relay Load: "+relay.connected+"/"+relay.capacity+"\\n";
  message += "Audio distributed via pub-to-pub mesh.";

  res.send(message);
});

app.listen(4000,()=>console.log("Distributed Audio Mesh API running"));
