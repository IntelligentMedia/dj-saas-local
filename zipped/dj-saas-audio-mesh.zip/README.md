
DISTRIBUTED AUDIO MESH ENGINE

Logic:
- Some pubs act as relay nodes
- Audio can be distributed pub-to-pub
- Reduces central server bandwidth usage

Login:
dj1 / 1234
pub1 / 1234
