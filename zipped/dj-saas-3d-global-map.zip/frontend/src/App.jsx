
import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);

  useEffect(()=>{

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 🌍 Globe
    const geometry = new THREE.SphereGeometry(5, 64, 64);
    const material = new THREE.MeshBasicMaterial({wireframe:true});
    const globe = new THREE.Mesh(geometry, material);
    scene.add(globe);

    // 📡 DJ nodes (simulated)
    const nodeGeo = new THREE.SphereGeometry(0.15,16,16);
    const nodeMat = new THREE.MeshBasicMaterial();

    const positions = [
      {x:3,y:1,z:2},
      {x:-2,y:2,z:-3},
      {x:1,y:-2,z:3}
    ];

    positions.forEach(p=>{
      const node = new THREE.Mesh(nodeGeo,nodeMat);
      node.position.set(p.x,p.y,p.z);
      scene.add(node);
    });

    camera.position.z = 12;

    function animate(){
      requestAnimationFrame(animate);
      globe.rotation.y += 0.002;
      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div>
      <h1 style={{position:"absolute",color:"white",padding:10}}>🌍 3D Global Broadcast Map</h1>
      <div ref={mountRef}></div>
    </div>
  );
}
