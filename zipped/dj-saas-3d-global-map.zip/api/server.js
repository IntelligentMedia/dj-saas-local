
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/map-data",(req,res)=>{

  res.json({
    nodes:[
      {dj:"DJ Sam",country:"Lebanon"},
      {dj:"DJ Alex",country:"France"},
      {dj:"DJ Lina",country:"Brazil"}
    ]
  });

});

app.listen(4000,()=>console.log("3D Global Broadcast Map API running"));
