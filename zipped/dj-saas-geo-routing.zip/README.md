
GEO ROUTING ENGINE

System chooses nearest LiveKit node based on latitude & longitude.

Example:
Beirut users → Beirut node
Paris users → Paris node
USA users → New York node

Login:
dj1 / 1234
