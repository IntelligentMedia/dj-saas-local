
TIMED ACTIVATION CODE VERSION

Activation codes only work during booked session time.

Login:
pub1 / 1234

Setup:
1) Import xampp_schema.sql into phpMyAdmin
2) cd api -> npm install -> npm start
3) cd frontend -> npm install -> npm run dev
