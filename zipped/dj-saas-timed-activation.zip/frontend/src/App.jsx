
import React, { useState } from "react";

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [code,setCode]=useState("");
  const [status,setStatus]=useState("");

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const data=await res.json();
      localStorage.setItem("token",data.accessToken);
      setUser(data.user);
    }else alert("Login failed");
  };

  const validateCode=async()=>{
    const res = await fetch("http://localhost:4000/activate",{
      method:"POST",
      headers:{
        "Content-Type":"application/json",
        Authorization:"Bearer "+localStorage.getItem("token")
      },
      body:JSON.stringify({code})
    });

    const text = await res.text();
    setStatus(text);
  };

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Login</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return(
    <div style={{padding:20}}>
      <h1>{user.username} ({user.role})</h1>

      {user.role==="pub" && (
        <div>
          <h3>Enter Activation Code</h3>
          <input onChange={e=>setCode(e.target.value)} />
          <button onClick={validateCode}>Activate</button>
          <div>{status}</div>
        </div>
      )}
    </div>
  );
}
