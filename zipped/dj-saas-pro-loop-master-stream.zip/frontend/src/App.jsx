
import React, { useEffect, useRef, useState } from "react";

export default function App(){

  const audioRef = useRef(null);
  const ctxRef = useRef(null);
  const destRef = useRef(null);

  const [loopSize,setLoopSize] = useState(0);
  const [isLooping,setIsLooping] = useState(false);

  useEffect(()=>{

    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    ctxRef.current = ctx;

    const audio = audioRef.current;

    const source = ctx.createMediaElementSource(audio);
    const dest = ctx.createMediaStreamDestination();

    source.connect(dest);
    source.connect(ctx.destination);

    destRef.current = dest;

  },[]);

  // 🔁 LOOP ENGINE
  useEffect(()=>{

    const audio = audioRef.current;

    const interval = setInterval(()=>{

      if(!isLooping || loopSize === 0) return;

      const end = audio.dataset.loopEnd ? parseFloat(audio.dataset.loopEnd) : 0;

      if(audio.currentTime >= end){
        audio.currentTime = parseFloat(audio.dataset.loopStart || 0);
      }

    },50);

    return ()=>clearInterval(interval);

  },[isLooping,loopSize]);

  const startLoop=(beats)=>{

    const audio = audioRef.current;

    const bpm = 120; // simulated bpm
    const beatDuration = 60 / bpm;

    const start = audio.currentTime;
    const end = start + (beatDuration * beats);

    audio.dataset.loopStart = start;
    audio.dataset.loopEnd = end;

    setLoopSize(beats);
    setIsLooping(true);
  };

  const stopLoop=()=>{
    setIsLooping(false);
  };

  // 📡 MASTER OUTPUT STREAM SIMULATION
  const publishMasterOutput=()=>{

    const stream = destRef.current.stream;

    console.log("MASTER STREAM READY:",stream);

    alert("Master Output Stream Ready (Connect to LiveKit here)");
  };

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🎛️ Pro Loop + Master Output Engine</h1>

      <audio
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      />

      <div style={{marginTop:10}}>
        <button onClick={()=>audioRef.current.play()}>Play</button>
        <button onClick={()=>audioRef.current.pause()}>Pause</button>
      </div>

      <h3>🔁 Loop Controls</h3>
      <button onClick={()=>startLoop(1)}>1 Beat Loop</button>
      <button onClick={()=>startLoop(2)}>2 Beat Loop</button>
      <button onClick={()=>startLoop(4)}>4 Beat Loop</button>
      <button onClick={()=>startLoop(8)}>8 Beat Loop</button>
      <button onClick={stopLoop}>Stop Loop</button>

      <h3 style={{marginTop:20}}>📡 Master Output</h3>
      <button onClick={publishMasterOutput}>Publish Master Stream</button>

    </div>
  );
}
