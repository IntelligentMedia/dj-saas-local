
MULTI DJ GLOBAL BROADCAST CORE

Features:
- Multiple LiveKit rooms
- DJs publish to different rooms
- Pubs auto join selected room
- Global broadcast routing system

Run:
1) livekit-server --dev
2) cd api && npm install && npm start
3) cd frontend && npm install && npm run dev
