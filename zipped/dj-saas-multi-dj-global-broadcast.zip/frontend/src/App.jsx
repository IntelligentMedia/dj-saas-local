
import React, { useState } from "react";
import { connect } from "livekit-client";

export default function App(){

  const [roomName,setRoomName]=useState("global-room");
  const [status,setStatus]=useState("Disconnected");

  const joinRoom = async ()=>{

    try{

      const tokenRes = await fetch("http://localhost:4000/token?room="+roomName);
      const data = await tokenRes.json();

      const room = await connect("ws://localhost:7880", data.token);

      setStatus("Connected to "+roomName);

      room.on("trackSubscribed", (track)=>{
        const el = track.attach();
        el.autoplay = true;
        document.body.appendChild(el);
      });

    }catch(e){
      console.error(e);
      setStatus("Connection failed");
    }
  };

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🌍 Multi DJ Global Broadcast Core</h1>

      <div>
        Room:
        <input value={roomName}
          onChange={e=>setRoomName(e.target.value)}
          style={{marginLeft:10}}/>
      </div>

      <button style={{marginTop:20}} onClick={joinRoom}>
        Join Broadcast Room
      </button>

      <h3>Status: {status}</h3>

    </div>
  );
}
