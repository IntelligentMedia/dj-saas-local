
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="PRO_DJ_DASHBOARD_SECRET";

// Simulated system stats
let sessionStart = Date.now();
let activePubs = 3;

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

// Demo login
app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  if(password!=="1234") return res.status(401).send("Invalid");

  const role = username.startsWith("dj") ? "dj":"pub";

  const token = jwt.sign({id:1,role},AUTH_SECRET,{expiresIn:"2h"});
  res.json({accessToken:token,user:{username,role}});
});

// 🎧 PRO DJ DASHBOARD DATA
app.get("/pro-dashboard",auth,(req,res)=>{

  const elapsedMs = Date.now() - sessionStart;
  const elapsedMinutes = Math.floor(elapsedMs/60000);

  const earnings = (elapsedMinutes/60) * 50;
  const nodeLoad = Math.floor(Math.random()*100);
  const streamHealth = nodeLoad < 70 ? "🟢 GOOD":"🟠 HIGH LOAD";

  let output = "";
  output += "Active Pubs: "+activePubs+"\\n";
  output += "Session Minutes: "+elapsedMinutes+"\\n";
  output += "Live Earnings: $"+earnings.toFixed(2)+"\\n";
  output += "Node Load: "+nodeLoad+"%\\n";
  output += "Stream Health: "+streamHealth+"\\n";
  output += "Auto Scaling: ENABLED\\n";
  output += "Edge Mode: ACTIVE\\n";

  res.send(output);
});

app.listen(4000,()=>console.log("Pro DJ Dashboard API running"));
