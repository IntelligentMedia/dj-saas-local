
PRO DJ DASHBOARD

Features:
- Live earnings counter
- Active pubs monitor
- Stream health indicator
- Node load status
- Auto updating every 2 seconds

Login:
dj1 / 1234
