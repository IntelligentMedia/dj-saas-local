
ADMIN DASHBOARD VERSION

Login Accounts:
admin / 1234
dj1 / 1234
pub1 / 1234

Steps:
1) Start XAMPP MySQL
2) Import xampp_schema.sql
3) cd api -> npm install -> npm start
4) cd frontend -> npm install -> npm run dev
