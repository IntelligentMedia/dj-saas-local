
AI CROWD ENERGY ANALYZER

Features:
- Simulated crowd energy scoring
- AI DJ priority recommendation
- Genre boost suggestion
