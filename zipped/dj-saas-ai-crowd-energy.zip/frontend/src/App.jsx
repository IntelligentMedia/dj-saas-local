
import React, { useEffect, useState } from "react";

export default function App(){

  const [energy,setEnergy] = useState(null);

  useEffect(()=>{

    const interval = setInterval(async()=>{
      const res = await fetch("http://localhost:4000/ai/crowd-energy");
      const json = await res.json();
      setEnergy(json);
    },2000);

    return ()=>clearInterval(interval);

  },[]);

  if(!energy) return <div style={{padding:20}}>Analyzing crowd energy...</div>;

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🤖 AI Crowd Energy Analyzer</h1>

      <div style={{marginTop:20}}>
        <h3>🔥 Current Energy Score: {energy.score}</h3>
        <h3>🎧 Top DJ: {energy.topDj}</h3>
        <h3>🎵 Recommended Genre Boost: {energy.genre}</h3>
      </div>

      <div style={{marginTop:30,background:"#111",color:"#0f0",padding:20,width:500}}>
        {energy.log.map((l,i)=>(
          <div key={i}>{l}</div>
        ))}
      </div>

    </div>
  );
}
