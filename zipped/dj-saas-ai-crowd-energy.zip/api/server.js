
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

function randomInt(min,max){
  return Math.floor(Math.random()*(max-min+1))+min;
}

// 🤖 AI Crowd Energy Simulation
app.get("/ai/crowd-energy",(req,res)=>{

  const score = randomInt(40,100);

  let topDj = "DJ Sam";
  let genre = "House";

  if(score > 80){
    topDj = "DJ Alex";
    genre = "Techno";
  }
  if(score < 60){
    topDj = "DJ Lina";
    genre = "Lounge";
  }

  const data = {
    score,
    topDj,
    genre,
    log:[
      "Analyzing pub audio feedback...",
      "Detecting crowd noise level...",
      "Measuring beat intensity...",
      "AI recommending DJ priority shift"
    ]
  };

  res.json(data);
});

app.listen(4000,()=>console.log("AI Crowd Energy Analyzer running"));
