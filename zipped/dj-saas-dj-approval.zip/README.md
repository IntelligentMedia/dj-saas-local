
DJ APPROVAL SYSTEM VERSION

Admin approves DJs before they can stream.

Login:
admin / 1234
dj1 / 1234

Setup:
1) Import xampp_schema.sql into phpMyAdmin
2) cd api -> npm install -> npm start
3) cd frontend -> npm install -> npm run dev
