
import React, { useState } from "react";

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [users,setUsers]=useState([]);

  const getToken=()=>localStorage.getItem("accessToken");

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const data=await res.json();
      localStorage.setItem("accessToken",data.accessToken);
      setUser(data.user);
      if(data.user.role==="admin") loadUsers();
    }else alert("Login failed");
  };

  const loadUsers=async()=>{
    const res=await fetch("http://localhost:4000/admin/djs",{
      headers:{Authorization:"Bearer "+getToken()}
    });
    const data=await res.json();
    setUsers(data);
  };

  const approveDJ=async(id)=>{
    await fetch("http://localhost:4000/admin/approve-dj/"+id,{
      method:"POST",
      headers:{Authorization:"Bearer "+getToken()}
    });
    loadUsers();
  };

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Login</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return(
    <div style={{padding:20}}>
      <h1>Welcome {user.username} ({user.role})</h1>

      {user.role==="admin" && (
        <div>
          <h2>DJ Approval Panel</h2>
          <button onClick={loadUsers}>Load DJs</button>
          {users.map(u=>(
            <div key={u.id}>
              {u.username} - Approved: {u.approved ? "YES":"NO"}
              {!u.approved && <button onClick={()=>approveDJ(u.id)}>Approve</button>}
            </div>
          ))}
        </div>
      )}

      {user.role==="dj" && (
        <div>
          {user.approved ? "DJ Approved - Can Stream" : "Waiting for Admin Approval"}
        </div>
      )}
    </div>
  );
}
