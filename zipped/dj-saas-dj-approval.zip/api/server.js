
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const app = express();
app.use(cors());
app.use(express.json());

const SECRET="ACCESS_SECRET_KEY";

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

function auth(req,res,next){
  const header = req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token = header.split(" ")[1];
  jwt.verify(token,SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

function adminOnly(req,res,next){
  if(req.user.role!=="admin") return res.sendStatus(403);
  next();
}

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=?",[username],async(err,rows)=>{
    if(!rows || rows.length===0) return res.status(401).send("Invalid");

    const user = rows[0];
    const match = await bcrypt.compare(password,user.password);
    if(!match) return res.status(401).send("Invalid");

    const token = jwt.sign({id:user.id,role:user.role,approved:user.approved},SECRET,{expiresIn:"1h"});

    res.json({
      accessToken:token,
      user:{username:user.username,role:user.role,approved:user.approved}
    });
  });
});

app.get("/admin/djs",auth,adminOnly,(req,res)=>{
  db.query("SELECT id,username,approved FROM users WHERE role='dj'",(err,rows)=>{
    res.json(rows);
  });
});

app.post("/admin/approve-dj/:id",auth,adminOnly,(req,res)=>{
  db.query("UPDATE users SET approved=1 WHERE id=?",[req.params.id]);
  res.json({ok:true});
});

app.listen(4000,()=>console.log("DJ Approval API running"));
