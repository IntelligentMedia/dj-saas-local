
AI AUTO DJ FAILOVER ENGINE

Features:
- Detect DJ disconnect (simulated)
- Auto switch to backup AI DJ
- Continuous music protection
- Designed for LiveKit integration
