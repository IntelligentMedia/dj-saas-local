
import React, { useEffect, useState } from "react";

export default function App(){

  const [status,setStatus] = useState("Monitoring DJs...");

  useEffect(()=>{

    const interval = setInterval(async()=>{
      const res = await fetch("http://localhost:4000/failover/status");
      const text = await res.text();
      setStatus(text);
    },2000);

    return ()=>clearInterval(interval);

  },[]);

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🤖 AI Auto DJ Failover Engine</h1>

      <div style={{marginTop:20,background:"#111",color:"#0f0",padding:20,width:500}}>
        {status}
      </div>

    </div>
  );
}
