
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Simulated DJ stream state
let djOnline = true;
let currentDJ = "DJ Sam";
let backupDJ = "AI Backup DJ";

// Randomly simulate DJ disconnect
setInterval(()=>{
  const rand = Math.random();
  if(rand > 0.7){
    djOnline = false;
  }else{
    djOnline = true;
  }
},5000);

// 🤖 AI FAILOVER ENGINE
app.get("/failover/status",(req,res)=>{

  let message = "";

  if(djOnline){
    message += "🎧 Active DJ: "+currentDJ+"\\n";
    message += "Status: LIVE STREAM OK";
  }else{
    message += "⚠️ DJ DISCONNECTED\\n";
    message += "🤖 AI Loading Backup DJ...\\n";
    message += "🔁 Crossfading to "+backupDJ;
  }

  res.send(message);
});

app.listen(4000,()=>console.log("AI Auto DJ Failover Engine running"));
