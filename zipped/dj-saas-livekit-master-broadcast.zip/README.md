
LIVEKIT MASTER OUTPUT BROADCAST

Steps:
1) Run LiveKit locally
2) Start API: npm install && npm start
3) Start frontend: npm install && npm run dev
4) Replace TOKEN placeholder with API /token result
