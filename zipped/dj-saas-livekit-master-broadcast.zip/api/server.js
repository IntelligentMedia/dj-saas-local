
const express = require("express");
const cors = require("cors");
const { AccessToken } = require("livekit-server-sdk");

const app = express();
app.use(cors());
app.use(express.json());

const LIVEKIT_API_KEY="devkey";
const LIVEKIT_API_SECRET="secret";

app.get("/token",(req,res)=>{

  const at = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
    identity: "dj-user"
  });

  at.addGrant({
    roomJoin: true,
    room: "dj-room",
    canPublish: true,
    canSubscribe: true
  });

  res.json({ token: at.toJwt() });
});

app.listen(4000,()=>console.log("LiveKit Token Server running"));
