
import React, { useEffect, useRef } from "react";
import { connect } from "livekit-client";

export default function App(){

  const audioRef = useRef(null);
  const ctxRef = useRef(null);
  const destRef = useRef(null);

  useEffect(()=>{

    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    ctxRef.current = ctx;

    const audio = audioRef.current;

    const source = ctx.createMediaElementSource(audio);
    const dest = ctx.createMediaStreamDestination();

    source.connect(dest);
    source.connect(ctx.destination);

    destRef.current = dest;

  },[]);

  const publishToLiveKit = async ()=>{

    const LIVEKIT_URL = "ws://localhost:7880"; // change later
    const TOKEN = "PASTE_GENERATED_TOKEN_HERE"; // from backend

    try{

      const room = await connect(LIVEKIT_URL, TOKEN);

      const stream = destRef.current.stream;
      const track = stream.getAudioTracks()[0];

      await room.localParticipant.publishTrack(track);

      alert("🎧 Master Output Connected to LiveKit Broadcast");

    }catch(e){
      console.error(e);
      alert("LiveKit connection failed");
    }
  };

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🎧 LiveKit Master Broadcast Engine</h1>

      <audio
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      />

      <div style={{marginTop:10}}>
        <button onClick={()=>audioRef.current.play()}>Play</button>
        <button onClick={()=>audioRef.current.pause()}>Pause</button>
      </div>

      <h3 style={{marginTop:20}}>📡 Broadcast</h3>
      <button onClick={publishToLiveKit}>Connect Master Output to LiveKit</button>

    </div>
  );
}
