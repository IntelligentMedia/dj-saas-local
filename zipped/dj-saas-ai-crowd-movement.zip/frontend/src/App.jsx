
import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);
  const audioRef = useRef(null);

  useEffect(()=>{

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 🎧 DJ Stage
    const stage = new THREE.Mesh(
      new THREE.BoxGeometry(4,0.5,4),
      new THREE.MeshBasicMaterial({wireframe:true})
    );
    stage.position.y = 0.25;
    scene.add(stage);

    // 🧍 Crowd avatars
    const crowd = [];
    const crowdMat = new THREE.MeshBasicMaterial({color:0x00f0ff, wireframe:true});

    for(let i=0;i<30;i++){
      const person = new THREE.Mesh(
        new THREE.BoxGeometry(0.3,1,0.3),
        crowdMat
      );
      person.position.set((Math.random()-0.5)*12,0,(Math.random()-0.5)*12);
      scene.add(person);
      crowd.push(person);
    }

    camera.position.set(0,8,12);
    camera.lookAt(0,0,0);

    // 🔊 Audio analyser
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    const audio = audioRef.current;
    const source = ctx.createMediaElementSource(audio);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser).connect(ctx.destination);

    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    function animate(){
      requestAnimationFrame(animate);

      analyser.getByteFrequencyData(dataArray);

      let sum=0;
      for(let i=0;i<dataArray.length;i++){
        sum+=dataArray[i];
      }
      const energy = sum/dataArray.length/255;

      // 🤖 AI Crowd Movement Logic
      crowd.forEach((p,i)=>{

        // dance bounce
        p.position.y = Math.sin(Date.now()*0.005 + i)*energy;

        // move slightly toward DJ stage when energy high
        if(energy > 0.5){
          p.position.x *= 0.999;
          p.position.z *= 0.999;
        }

        // hand wave rotation
        p.rotation.y += 0.01 + energy*0.05;
      });

      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#000"}}>
      <h1 style={{position:"absolute",color:"#00f0ff",padding:15}}>
        🧍🔥 AI Crowd Movement Engine
      </h1>

      <audio
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      />

      <div style={{position:"absolute",top:60,left:20,color:"#fff"}}>
        <button onClick={()=>audioRef.current.play()}>Play Music</button>
      </div>

      <div ref={mountRef}></div>
    </div>
  );
}
