
AI CROWD MOVEMENT ENGINE

Features:
- Beat reactive crowd dancing
- Crowd moves toward DJ when energy rises
- AI crowd behavior simulation
- Designed for metaverse DJ environments
