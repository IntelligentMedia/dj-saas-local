
import React, { useState } from "react";

function Deck({name}){
  const [volume,setVolume]=useState(50);

  return(
    <div style={{border:"1px solid #ccc",padding:20,width:250}}>
      <h3>{name}</h3>
      <div>🎵 Track Loaded</div>
      <input type="range" min="0" max="100"
        value={volume}
        onChange={e=>setVolume(e.target.value)}
        style={{width:"100%"}}/>
      <div>Volume: {volume}%</div>
      <button>Play</button>
      <button>Pause</button>
    </div>
  );
}

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const json=await res.json();
      localStorage.setItem("auth",json.accessToken);
      setUser(json.user);
    }else alert("Login failed");
  };

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Login</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>
      <h1>🎚️ Web DJ Studio Interface</h1>

      <div style={{display:"flex",gap:20}}>
        <Deck name="Deck A"/>
        <Deck name="Deck B"/>
      </div>

      <div style={{marginTop:30,width:500}}>
        <h3>🎛️ Mixer Crossfader</h3>
        <input type="range" min="0" max="100" defaultValue="50" style={{width:"100%"}}/>
        <div>A ← Crossfader → B</div>
      </div>
    </div>
  );
}
