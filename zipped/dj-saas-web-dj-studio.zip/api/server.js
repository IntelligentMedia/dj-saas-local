
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="WEB_DJ_STUDIO_SECRET";

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  if(password!=="1234") return res.status(401).send("Invalid");

  const role = username.startsWith("dj") ? "dj":"pub";

  const token = jwt.sign({id:1,role},AUTH_SECRET,{expiresIn:"2h"});

  res.json({
    accessToken:token,
    user:{username,role}
  });
});

app.listen(4000,()=>console.log("Web DJ Studio API running"));
