
WEB DJ STUDIO INTERFACE

Features:
- Dual Deck UI
- Crossfader mixer
- Volume sliders
- Play / Pause controls

Login:
dj1 / 1234
