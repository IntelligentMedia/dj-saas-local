
AI DJ AVATAR SYSTEM

Features:
- 3D holographic DJ avatar
- Avatar moves with music energy
- Arms animate to beat intensity
- Neon wireframe visual style
