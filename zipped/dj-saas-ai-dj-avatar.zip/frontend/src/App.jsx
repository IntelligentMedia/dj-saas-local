
import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);
  const audioRef = useRef(null);

  useEffect(()=>{

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true, alpha:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 🎧 AI DJ Avatar (simple humanoid figure)
    const material = new THREE.MeshBasicMaterial({color:0x00f0ff, wireframe:true});

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.6,16,16), material);
    head.position.y = 2.5;

    const body = new THREE.Mesh(new THREE.BoxGeometry(1.2,2,0.6), material);
    body.position.y = 1;

    const leftArm = new THREE.Mesh(new THREE.BoxGeometry(0.4,1.5,0.4), material);
    leftArm.position.set(-1,1.5,0);

    const rightArm = new THREE.Mesh(new THREE.BoxGeometry(0.4,1.5,0.4), material);
    rightArm.position.set(1,1.5,0);

    const avatar = new THREE.Group();
    avatar.add(head);
    avatar.add(body);
    avatar.add(leftArm);
    avatar.add(rightArm);
    scene.add(avatar);

    camera.position.z = 8;

    // 🔊 WebAudio analyser
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    const audio = audioRef.current;
    const source = ctx.createMediaElementSource(audio);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;

    source.connect(analyser).connect(ctx.destination);
    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    function animate(){
      requestAnimationFrame(animate);

      analyser.getByteFrequencyData(dataArray);

      let sum=0;
      for(let i=0;i<dataArray.length;i++){
        sum += dataArray[i];
      }
      const avg = sum/dataArray.length;

      // 🤖 Avatar reacts to music energy
      avatar.rotation.y += 0.01;
      avatar.position.y = Math.sin(Date.now()*0.002)*(avg/255);

      leftArm.rotation.z = Math.sin(Date.now()*0.005)*(avg/255);
      rightArm.rotation.z = -Math.sin(Date.now()*0.005)*(avg/255);

      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#02040a",height:"100vh"}}>
      <h1 style={{position:"absolute",color:"#00f0ff",padding:15,textShadow:"0 0 10px #00f0ff"}}>
        🤖 AI DJ Avatar System
      </h1>

      <audio
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      />

      <div style={{position:"absolute",top:70,left:20,color:"#fff"}}>
        <button onClick={()=>audioRef.current.play()}>Play Music</button>
      </div>

      <div ref={mountRef}></div>
    </div>
  );
}
