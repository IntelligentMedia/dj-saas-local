
WAVEFORM + BEATGRID ENGINE

Features:
- Live waveform rendering using WebAudio analyser
- Beatgrid overlay (visual bars)
- Canvas-based visualization
