
import React, { useEffect, useRef, useState } from "react";

export default function App(){

  const audioRef = useRef(null);
  const canvasRef = useRef(null);
  const [ctx,setCtx] = useState(null);

  useEffect(()=>{
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const audioCtx = new AudioContext();
    setCtx(audioCtx);

    const audio = audioRef.current;
    const source = audioCtx.createMediaElementSource(audio);
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 2048;

    source.connect(analyser).connect(audioCtx.destination);

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const canvas = canvasRef.current;
    const canvasCtx = canvas.getContext("2d");

    function draw(){
      requestAnimationFrame(draw);

      analyser.getByteTimeDomainData(dataArray);

      canvasCtx.fillStyle = "#111";
      canvasCtx.fillRect(0,0,canvas.width,canvas.height);

      canvasCtx.lineWidth = 2;
      canvasCtx.strokeStyle = "#4caf50";
      canvasCtx.beginPath();

      const sliceWidth = canvas.width * 1.0 / bufferLength;
      let x = 0;

      for(let i=0;i<bufferLength;i++){
        const v = dataArray[i] / 128.0;
        const y = v * canvas.height/2;

        if(i===0){
          canvasCtx.moveTo(x,y);
        }else{
          canvasCtx.lineTo(x,y);
        }

        x += sliceWidth;
      }

      canvasCtx.lineTo(canvas.width,canvas.height/2);
      canvasCtx.stroke();
    }

    draw();

  },[]);

  // Fake beatgrid generator
  const renderBeatGrid = ()=>{
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    ctx.strokeStyle="#ff9800";
    for(let i=0;i<canvas.width;i+=50){
      ctx.beginPath();
      ctx.moveTo(i,0);
      ctx.lineTo(i,canvas.height);
      ctx.stroke();
    }
  };

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🎵 Waveform + Beatgrid Engine</h1>

      <audio
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      />

      <div style={{marginTop:10}}>
        <button onClick={()=>audioRef.current.play()}>Play</button>
        <button onClick={()=>audioRef.current.pause()}>Pause</button>
        <button onClick={renderBeatGrid}>⚡ Generate Beatgrid</button>
      </div>

      <canvas ref={canvasRef} width="800" height="200"
        style={{background:"#111",marginTop:20}}/>

    </div>
  );
}
