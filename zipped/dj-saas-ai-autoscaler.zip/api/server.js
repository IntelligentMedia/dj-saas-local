
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const { exec } = require("child_process");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="AI_AUTOSCALER_SECRET";

// Simulated node pool
let LIVEKIT_NODES = [
  { url:"ws://localhost:7880", load:40 },
  { url:"ws://localhost:7882", load:65 }
];

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

// Demo login
app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  if(password!=="1234") return res.status(401).send("Invalid");

  const role = username.startsWith("dj") ? "dj":"pub";

  const token = jwt.sign({id:1,role},AUTH_SECRET,{expiresIn:"2h"});
  res.json({accessToken:token,user:{username,role}});
});

// 🤖 AI AUTOSCALER LOGIC
app.get("/ai-scale",auth,(req,res)=>{

  // simulate load measurement
  LIVEKIT_NODES.forEach(n=>{
    n.load = Math.floor(Math.random()*100);
  });

  const avgLoad = LIVEKIT_NODES.reduce((a,b)=>a+b.load,0)/LIVEKIT_NODES.length;

  if(avgLoad > 70){
    // Simulate launching new LiveKit node
    const newPort = 7900 + LIVEKIT_NODES.length;
    const newNode = { url:"ws://localhost:"+newPort, load:10 };
    LIVEKIT_NODES.push(newNode);

    res.send("AI AUTOSCALER: High load detected ("+avgLoad+"%). New node launched at "+newNode.url);
  }else if(avgLoad < 25 && LIVEKIT_NODES.length > 1){
    const removed = LIVEKIT_NODES.pop();
    res.send("AI AUTOSCALER: Low load ("+avgLoad+"%). Node removed "+removed.url);
  }else{
    res.send("AI AUTOSCALER: System stable. Avg load "+avgLoad+"%");
  }

});

app.listen(4000,()=>console.log("AI Autoscaler API running"));
