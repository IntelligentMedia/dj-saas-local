
AI AUTOSCALER SYSTEM

System monitors node load and automatically scales LiveKit nodes.

Logic:
- High load → launch new node
- Low load → remove node
- Stable load → no action

Login:
dj1 / 1234
pub1 / 1234
