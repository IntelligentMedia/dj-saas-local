
import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { Room, RoomEvent } from "livekit-client";

export default function App(){

  const mountRef = useRef(null);

  useEffect(()=>{

    const room = new Room();

    async function connect(){
      try{
        await room.connect("wss://YOUR_LIVEKIT_URL", "YOUR_TOKEN");
      }catch(e){
        console.log("LiveKit demo mode");
      }
    }
    connect();

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    const material = new THREE.MeshBasicMaterial({color:0x00f0ff,wireframe:true});

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.6,16,16), material);
    head.position.y = 2;

    const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.4,0.1,0.1), material);
    mouth.position.set(0,1.8,0.6);

    const avatar = new THREE.Group();
    avatar.add(head);
    avatar.add(mouth);
    scene.add(avatar);

    camera.position.z = 6;

    let voiceEnergy = 0;

    room.on(RoomEvent.TrackSubscribed, ()=>{
      console.log("Track subscribed");
    });

    function animate(){
      requestAnimationFrame(animate);
      voiceEnergy = Math.abs(Math.sin(Date.now()*0.005));
      mouth.scale.y = 0.5 + voiceEnergy;
      avatar.rotation.y += 0.01;
      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#000"}}>
      <h1 style={{position:"absolute",color:"#00f0ff",padding:15}}>
        🎧🤖 LiveKit Voice Avatar Sync Engine
      </h1>
      <div ref={mountRef}></div>
    </div>
  );
}
