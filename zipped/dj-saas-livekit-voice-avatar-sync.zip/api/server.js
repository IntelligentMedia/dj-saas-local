
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());

app.get("/token",(req,res)=>{
  res.json({token:"REPLACE_WITH_REAL_TOKEN"});
});

app.listen(4000,()=>console.log("LiveKit Token API running"));
