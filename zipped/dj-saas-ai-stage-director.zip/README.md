
AI STAGE DIRECTOR SYSTEM

Features:
- AI camera auto zoom
- Beat reactive lighting control
- Automatic stage focus on DJ avatar
- Designed for metaverse DJ environments
