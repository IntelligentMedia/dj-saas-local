
import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);
  const audioRef = useRef(null);

  useEffect(()=>{

    const scene = new THREE.Scene();

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 🎧 Stage
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(20,20),
      new THREE.MeshBasicMaterial({wireframe:true})
    );
    floor.rotation.x = -Math.PI/2;
    scene.add(floor);

    // 🤖 DJ Avatar
    const avatarMat = new THREE.MeshBasicMaterial({color:0x00f0ff,wireframe:true});
    const avatar = new THREE.Mesh(new THREE.BoxGeometry(1,2,1),avatarMat);
    avatar.position.y = 1;
    scene.add(avatar);

    // 💡 Lights
    const lights=[];
    for(let i=0;i<4;i++){
      const l=new THREE.PointLight(0xff00ff,1,30);
      l.position.set(Math.sin(i)*5,3,Math.cos(i)*5);
      scene.add(l);
      lights.push(l);
    }

    camera.position.set(0,6,10);
    camera.lookAt(0,0,0);

    // 🔊 Audio analyser
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    const audio = audioRef.current;
    const source = ctx.createMediaElementSource(audio);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser).connect(ctx.destination);

    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    // 🎥 AI Stage Director Logic
    function animate(){
      requestAnimationFrame(animate);

      analyser.getByteFrequencyData(dataArray);

      let sum=0;
      for(let i=0;i<dataArray.length;i++){
        sum+=dataArray[i];
      }

      const energy = sum/dataArray.length/255;

      // 🤖 Camera AI: zoom based on energy
      camera.position.z = 10 - energy*4;
      camera.position.y = 6 - energy*2;
      camera.lookAt(avatar.position);

      // 💡 Light AI
      lights.forEach((l,i)=>{
        l.intensity = 1 + energy*4;
        l.color.setHSL((Date.now()*0.0003+i*0.1)%1,1,0.5);
      });

      // 🎧 Avatar bounce
      avatar.position.y = 1 + Math.sin(Date.now()*0.005)*energy;

      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#000"}}>
      <h1 style={{position:"absolute",color:"#00f0ff",padding:15}}>
        🎥🤖 AI Stage Director System
      </h1>

      <audio
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      />

      <div style={{position:"absolute",top:60,left:20,color:"#fff"}}>
        <button onClick={()=>audioRef.current.play()}>Play Music</button>
      </div>

      <div ref={mountRef}></div>
    </div>
  );
}
