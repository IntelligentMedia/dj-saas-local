
import React, { useState, useEffect, useRef } from "react";

export default function App() {
  const [role, setRole] = useState(null);
  const [session, setSession] = useState({ live: false, seconds: 0 });
  const [cross, setCross] = useState(50);
  const [activationInput, setActivationInput] = useState("");
  const [connectedPubs, setConnectedPubs] = useState([]);

  const ACTIVATION_CODE = "PUB-555";

  const audioA = useRef(null);
  const audioB = useRef(null);
  const videoCanvas = useRef(null);

  const ctxRef = useRef(null);
  const gainARef = useRef(null);
  const gainBRef = useRef(null);
  const masterGainRef = useRef(null);
  const streamDestRef = useRef(null);
  const masterBroadcastStream = useRef(null);

  useEffect(() => {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    ctxRef.current = ctx;

    const sourceA = ctx.createMediaElementSource(audioA.current);
    const sourceB = ctx.createMediaElementSource(audioB.current);

    const gainA = ctx.createGain();
    const gainB = ctx.createGain();
    const masterGain = ctx.createGain();
    const streamDest = ctx.createMediaStreamDestination();

    gainARef.current = gainA;
    gainBRef.current = gainB;
    masterGainRef.current = masterGain;
    streamDestRef.current = streamDest;

    sourceA.connect(gainA).connect(masterGain);
    sourceB.connect(gainB).connect(masterGain);

    masterGain.connect(ctx.destination);
    masterGain.connect(streamDest);

    startVideoRenderLoop();
  }, []);

  useEffect(() => {
    if (!session.live) return;

    const timer = setInterval(() => {
      setSession((prev) => {
        if (prev.seconds <= 1) {
          stopSession();
          return { live: false, seconds: 0 };
        }
        return { ...prev, seconds: prev.seconds - 1 };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [session.live]);

  const startVideoRenderLoop = () => {
    const canvas = videoCanvas.current;
    const ctx = canvas.getContext("2d");

    const draw = () => {
      ctx.fillStyle = "black";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = "lime";
      ctx.font = "22px Arial";
      ctx.fillText("DJ SAAS LIVE", 20, 40);

      ctx.fillStyle = "white";
      ctx.fillText(`Pubs: ${connectedPubs.length}`, 20, 80);

      requestAnimationFrame(draw);
    };

    draw();
  };

  const updateCrossfader = (value) => {
    const x = value / 100;
    if (gainARef.current && gainBRef.current) {
      gainARef.current.gain.value = 1 - x;
      gainBRef.current.gain.value = x;
    }
  };

  useEffect(() => {
    updateCrossfader(cross);
  }, [cross]);

  const startSession = async () => {
    await ctxRef.current.resume();

    const canvasStream = videoCanvas.current.captureStream(30);

    const combined = new MediaStream([
      ...canvasStream.getVideoTracks(),
      ...streamDestRef.current.stream.getAudioTracks()
    ]);

    masterBroadcastStream.current = combined;

    setSession({ live: true, seconds: 900 });
  };

  const stopSession = () => {
    setSession({ live: false, seconds: 0 });
    setConnectedPubs([]);
    audioA.current.pause();
    audioB.current.pause();
  };

  const connectPub = () => {
    if (!session.live) return alert("DJ not live");
    if (activationInput !== ACTIVATION_CODE)
      return alert("Invalid activation code");

    const newPub = {
      id: Date.now(),
      stream: masterBroadcastStream.current
    };

    setConnectedPubs((p) => [...p, newPub]);
  };

  return (
    <div style={{ padding: 20, fontFamily: "Arial" }}>
      <h1>DJ SaaS Local Version</h1>

      {!role && (
        <div>
          <button onClick={() => setRole("dj")}>DJ Dashboard</button>
          <button onClick={() => setRole("pub")}>Pub Player</button>
        </div>
      )}

      {role === "dj" && (
        <div>
          {!session.live && <button onClick={startSession}>Start Broadcast</button>}
          {session.live && <div>LIVE {session.seconds}s</div>}

          <div>
            <button onClick={() => audioA.current.play()}>Deck A Play</button>
            <button onClick={() => audioB.current.play()}>Deck B Play</button>
          </div>

          <input
            type="range"
            min="0"
            max="100"
            value={cross}
            onChange={(e) => setCross(Number(e.target.value))}
          />

          <canvas ref={videoCanvas} width={640} height={360} style={{ border: "1px solid" }} />
        </div>
      )}

      {role === "pub" && (
        <div>
          <input value={activationInput} onChange={(e)=>setActivationInput(e.target.value)} />
          <button onClick={connectPub}>Join</button>

          {connectedPubs.map((pub) => (
            <video
              key={pub.id}
              autoPlay
              playsInline
              ref={(el) => {
                if (el && pub.stream) el.srcObject = pub.stream;
              }}
              style={{ width: "100%" }}
            />
          ))}
        </div>
      )}

      <audio ref={audioA} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" crossOrigin="anonymous" />
      <audio ref={audioB} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" crossOrigin="anonymous" />
    </div>
  );
}
