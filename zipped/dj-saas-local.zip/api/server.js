
const express = require("express");
const cors = require("cors");
const { v4: uuid } = require("uuid");

const app = express();
app.use(cors());
app.use(express.json());

let sessions = {};
let activationCodes = {};

app.post("/session/start", (req,res)=>{
  const id = uuid();
  sessions[id] = { live:true };
  const code = "PUB-555";
  activationCodes[code] = id;
  res.json({ sessionId:id, activationCode:code });
});

app.post("/session/stop",(req,res)=>{
  sessions = {};
  res.sendStatus(200);
});

app.post("/pub/join",(req,res)=>{
  const { code } = req.body;
  if(!activationCodes[code]) return res.status(403).send("Invalid");
  res.json({ stream:true });
});

app.listen(4000,()=>console.log("API running on 4000"));
