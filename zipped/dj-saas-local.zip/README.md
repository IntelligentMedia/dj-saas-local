
DJ SaaS Local Project

FRONTEND:
cd frontend
npm install
npm run dev

API:
cd api
npm install
npm start
