
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="PREDICTIVE_FORECAST_SECRET";

// Simulated historic pub usage (per hour)
const historicalTraffic = [
  {hour:0, load:10},
  {hour:6, load:20},
  {hour:12, load:40},
  {hour:18, load:80},
  {hour:22, load:95}
];

let LIVEKIT_NODES = [
  {url:"ws://localhost:7880"},
  {url:"ws://localhost:7882"}
];

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

// Demo login
app.post("/login",(req,res)=>{
  const {username,password}=req.body;
  if(password!=="1234") return res.status(401).send("Invalid");

  const role = username.startsWith("dj") ? "dj":"pub";

  const token = jwt.sign({id:1,role},AUTH_SECRET,{expiresIn:"2h"});
  res.json({accessToken:token,user:{username,role}});
});

// 📈 Predictive Load Forecaster
app.get("/predict-load",auth,(req,res)=>{

  const nowHour = new Date().getHours();

  // find closest forecast
  let prediction = historicalTraffic[0];
  historicalTraffic.forEach(h=>{
    if(Math.abs(h.hour-nowHour) < Math.abs(prediction.hour-nowHour)){
      prediction = h;
    }
  });

  let message = "Current hour: "+nowHour+"\\nPredicted load: "+prediction.load+"%\\n";

  if(prediction.load > 80){
    const newPort = 7900 + LIVEKIT_NODES.length;
    const newNode = {url:"ws://localhost:"+newPort};
    LIVEKIT_NODES.push(newNode);
    message += "AI Forecast: Peak hours incoming → Pre-scaling node "+newNode.url;
  }else{
    message += "AI Forecast: Load normal → No scaling required.";
  }

  res.send(message);
});

app.listen(4000,()=>console.log("Predictive Load Forecaster API running"));
