
PREDICTIVE LOAD FORECASTER

System predicts future load based on historic traffic and pre-scales LiveKit nodes.

Logic:
- Forecast peak hours
- Launch nodes BEFORE traffic spike

Login:
dj1 / 1234
pub1 / 1234
