
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(err=>{
  if(err) console.log("DB ERROR:",err);
  else console.log("MySQL Connected");
});

app.post("/session/start",(req,res)=>{
  db.query("INSERT INTO sessions (live) VALUES (1)");
  res.json({ok:true});
});

app.post("/pub/join",(req,res)=>{
  const {code}=req.body;
  db.query("SELECT * FROM activation_codes WHERE code=?",[code],(err,rows)=>{
    if(rows && rows.length>0) res.json({ok:true});
    else res.status(403).send("Invalid");
  });
});

app.listen(4000,()=>console.log("API running on 4000"));
