
import React, { useState, useEffect, useRef } from "react";

export default function App() {
  const [role, setRole] = useState(null);
  const [session, setSession] = useState({ live: false, seconds: 0 });
  const [activationInput, setActivationInput] = useState("");
  const [connectedPubs, setConnectedPubs] = useState([]);

  const audioA = useRef(null);
  const audioB = useRef(null);
  const videoCanvas = useRef(null);
  const masterStream = useRef(null);

  useEffect(()=>{
    const canvas = videoCanvas.current;
    const ctx = canvas.getContext("2d");

    const draw=()=>{
      ctx.fillStyle="black";
      ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.fillStyle="lime";
      ctx.font="20px Arial";
      ctx.fillText("DJ SAAS MYSQL VERSION",20,40);
      ctx.fillStyle="white";
      ctx.fillText("Pubs: "+connectedPubs.length,20,80);
      requestAnimationFrame(draw);
    };
    draw();
  },[connectedPubs]);

  const startSession=async()=>{
    const canvasStream = videoCanvas.current.captureStream(30);
    masterStream.current = canvasStream;
    setSession({live:true,seconds:900});
    await fetch("http://localhost:4000/session/start",{method:"POST"});
  };

  const connectPub=async()=>{
    const res = await fetch("http://localhost:4000/pub/join",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({code:activationInput})
    });

    if(res.ok){
      setConnectedPubs(p=>[...p,{id:Date.now(),stream:masterStream.current}]);
    }else{
      alert("Invalid Code");
    }
  };

  return (
    <div style={{padding:20,fontFamily:"Arial"}}>
      <h1>DJ SaaS MySQL XAMPP Version</h1>

      {!role && (
        <div>
          <button onClick={()=>setRole("dj")}>DJ Dashboard</button>
          <button onClick={()=>setRole("pub")}>Pub Player</button>
        </div>
      )}

      {role==="dj" && (
        <div>
          {!session.live && <button onClick={startSession}>Start Broadcast</button>}
          <div>
            <button onClick={()=>audioA.current.play()}>Deck A</button>
            <button onClick={()=>audioB.current.play()}>Deck B</button>
          </div>
          <canvas ref={videoCanvas} width={640} height={360} style={{border:"1px solid"}}/>
        </div>
      )}

      {role==="pub" && (
        <div>
          <input value={activationInput} onChange={(e)=>setActivationInput(e.target.value)}/>
          <button onClick={connectPub}>Join</button>

          {connectedPubs.map(pub=>(
            <video key={pub.id} autoPlay playsInline
              ref={(el)=>{ if(el && pub.stream) el.srcObject=pub.stream }}
              style={{width:"100%"}}/>
          ))}
        </div>
      )}

      <audio ref={audioA} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"/>
      <audio ref={audioB} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"/>
    </div>
  );
}
