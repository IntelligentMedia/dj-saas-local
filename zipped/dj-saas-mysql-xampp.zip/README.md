
XAMPP MYSQL VERSION

1) Start Apache + MySQL in XAMPP
2) Open phpMyAdmin
3) Import xampp_schema.sql

API:
cd api
npm install
npm start

FRONTEND:
cd frontend
npm install
npm run dev
