
SELF HEALING NODE SYSTEM

System automatically avoids failed LiveKit nodes.
If a node becomes unhealthy, users are routed to another healthy node.

Login examples:
dj1 / 1234
pub1 / 1234
