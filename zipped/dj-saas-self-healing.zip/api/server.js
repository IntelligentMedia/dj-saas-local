
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { AccessToken } = require("livekit-server-sdk");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="SELF_HEAL_SECRET";

// 🔥 Nodes with health status
let LIVEKIT_NODES = [
  { url:"ws://localhost:7880", key:"devkey", secret:"secret", healthy:true },
  { url:"ws://localhost:7882", key:"devkey", secret:"secret", healthy:true },
  { url:"ws://localhost:7884", key:"devkey", secret:"secret", healthy:true }
];

// Simulated node health monitor
setInterval(()=>{
  LIVEKIT_NODES.forEach(n=>{
    // randomly simulate node failure
    n.healthy = Math.random() > 0.3;
  });
},5000);

function chooseHealthyNode(){
  const healthyNodes = LIVEKIT_NODES.filter(n=>n.healthy);
  if(healthyNodes.length===0) return null;
  return healthyNodes[Math.floor(Math.random()*healthyNodes.length)];
}

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

// Fake login (demo purpose)
app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  if(password !== "1234") return res.status(401).send("Invalid");

  const role = username.startsWith("dj") ? "dj":"pub";

  const token = jwt.sign({
    id:1,
    role:role,
    approved:true
  },AUTH_SECRET,{expiresIn:"2h"});

  res.json({accessToken:token,user:{username,role}});
});

// 🔥 SELF HEALING TOKEN ENGINE
app.get("/healing-token",auth,(req,res)=>{

  const node = chooseHealthyNode();

  if(!node){
    return res.send("ALL NODES DOWN — RETRY");
  }

  const at = new AccessToken(node.key,node.secret,{
    identity:"user-"+req.user.id
  });

  at.addGrant({
    roomJoin:true,
    room:"global-broadcast-room",
    canPublish:req.user.role==="dj",
    canSubscribe:true
  });

  res.send("CONNECTED NODE: "+node.url+" | TOKEN: "+at.toJwt());
});

app.listen(4000,()=>console.log("Self Healing Node API running"));
