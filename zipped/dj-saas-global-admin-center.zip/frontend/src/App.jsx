
import React, { useEffect, useState } from "react";

function StatCard({title,value}){
  return(
    <div style={{border:"1px solid #ccc",padding:20,width:200}}>
      <h3>{title}</h3>
      <h2>{value}</h2>
    </div>
  );
}

export default function App(){

  const [stats,setStats]=useState(null);

  useEffect(()=>{

    const interval = setInterval(async()=>{
      const res = await fetch("http://localhost:4000/admin/stats");
      const json = await res.json();
      setStats(json);
    },2000);

    return ()=>clearInterval(interval);

  },[]);

  if(!stats) return <div style={{padding:20}}>Loading Global Admin Center...</div>;

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🌍 Global Admin Control Center</h1>

      <div style={{display:"flex",gap:20,marginTop:20}}>
        <StatCard title="🎧 DJs Live" value={stats.djs}/>
        <StatCard title="🍻 Pubs Connected" value={stats.pubs}/>
        <StatCard title="📡 Active Rooms" value={stats.rooms}/>
        <StatCard title="🤖 AI Decisions" value={stats.ai}/>
      </div>

      <h3 style={{marginTop:40}}>🌐 Global Stream Map</h3>
      <div style={{background:"#111",color:"#0f0",padding:20,width:600}}>
        {stats.map.map((m,i)=>(
          <div key={i}>
            DJ: {m.dj} → Room: {m.room} → Listeners: {m.listeners}
          </div>
        ))}
      </div>

    </div>
  );
}
