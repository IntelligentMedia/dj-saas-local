
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Simulated global platform state
function randomInt(min,max){
  return Math.floor(Math.random()*(max-min+1))+min;
}

app.get("/admin/stats",(req,res)=>{

  const data = {
    djs: randomInt(3,10),
    pubs: randomInt(20,100),
    rooms: randomInt(5,15),
    ai: randomInt(50,300),
    map:[
      {dj:"DJ Sam",room:"house-room",listeners:randomInt(10,50)},
      {dj:"DJ Alex",room:"techno-room",listeners:randomInt(5,40)},
      {dj:"DJ Lina",room:"lounge-room",listeners:randomInt(2,20)}
    ]
  };

  res.json(data);
});

app.listen(4000,()=>console.log("Global Admin Control Center API running"));
