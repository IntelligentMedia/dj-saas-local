
GLOBAL ADMIN CONTROL CENTER

Features:
- Live DJs counter
- Connected pubs stats
- Active rooms monitor
- AI routing decisions count
- Global DJ stream map
