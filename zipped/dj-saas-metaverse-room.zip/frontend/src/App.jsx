
import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);

  useEffect(()=>{

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 🌌 Floor
    const floorGeo = new THREE.PlaneGeometry(20,20);
    const floorMat = new THREE.MeshBasicMaterial({wireframe:true});
    const floor = new THREE.Mesh(floorGeo,floorMat);
    floor.rotation.x = -Math.PI/2;
    scene.add(floor);

    // 🤖 DJ Avatars (simulated multiplayer)
    const avatars = [];

    function createAvatar(x,z,color){
      const mat = new THREE.MeshBasicMaterial({color, wireframe:true});
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.4,16,16),mat);
      head.position.y = 1.5;

      const body = new THREE.Mesh(new THREE.BoxGeometry(0.8,1.5,0.4),mat);
      body.position.y = 0.5;

      const avatar = new THREE.Group();
      avatar.add(head);
      avatar.add(body);
      avatar.position.set(x,0,z);
      scene.add(avatar);
      avatars.push(avatar);
    }

    createAvatar(-3,0,0x00f0ff);
    createAvatar(3,0,0xff00ff);
    createAvatar(0,3,0xffff00);

    // 🧍 Crowd avatars
    for(let i=0;i<10;i++){
      const crowd = new THREE.Mesh(
        new THREE.BoxGeometry(0.3,1,0.3),
        new THREE.MeshBasicMaterial({wireframe:true})
      );
      crowd.position.set((Math.random()-0.5)*10,0,(Math.random()-0.5)*10);
      scene.add(crowd);
    }

    camera.position.set(0,6,10);
    camera.lookAt(0,0,0);

    function animate(){
      requestAnimationFrame(animate);

      avatars.forEach((a,i)=>{
        a.rotation.y += 0.01 + i*0.002;
        a.position.y = Math.sin(Date.now()*0.002+i)*0.2;
      });

      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#000"}}>
      <h1 style={{position:"absolute",color:"#00f0ff",padding:15,textShadow:"0 0 10px #00f0ff"}}>
        🌐 Multiplayer DJ Metaverse Room
      </h1>
      <div ref={mountRef}></div>
    </div>
  );
}
