
MULTIPLAYER DJ METAVERSE ROOM

Features:
- Multiple DJ avatars
- Crowd avatars
- 3D virtual room
- Foundation for realtime multiplayer
