
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());

app.get("/room-state",(req,res)=>{
  res.json({djs:3,crowd:10});
});

app.listen(4000,()=>console.log("Metaverse Room API running"));
