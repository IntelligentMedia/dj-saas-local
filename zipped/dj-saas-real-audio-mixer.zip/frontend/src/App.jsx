
import React, { useEffect, useRef, useState } from "react";

export default function App(){

  const audioCtxRef = useRef(null);
  const gainARef = useRef(null);
  const gainBRef = useRef(null);

  const audioARef = useRef(null);
  const audioBRef = useRef(null);

  const [cross,setCross] = useState(50);

  useEffect(()=>{

    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    audioCtxRef.current = ctx;

    const audioA = audioARef.current;
    const audioB = audioBRef.current;

    const sourceA = ctx.createMediaElementSource(audioA);
    const sourceB = ctx.createMediaElementSource(audioB);

    const gainA = ctx.createGain();
    const gainB = ctx.createGain();

    gainA.gain.value = 0.5;
    gainB.gain.value = 0.5;

    sourceA.connect(gainA).connect(ctx.destination);
    sourceB.connect(gainB).connect(ctx.destination);

    gainARef.current = gainA;
    gainBRef.current = gainB;

  },[]);

  const updateCross = (value)=>{
    setCross(value);

    if(!gainARef.current || !gainBRef.current) return;

    const a = 1 - value/100;
    const b = value/100;

    gainARef.current.gain.value = a;
    gainBRef.current.gain.value = b;
  };

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>

      <h1>🎚️ Real WebAudio DJ Mixer</h1>

      <div style={{display:"flex",gap:20}}>

        <div>
          <h3>Deck A</h3>
          <audio ref={audioARef} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"/>
          <button onClick={()=>audioARef.current.play()}>Play</button>
          <button onClick={()=>audioARef.current.pause()}>Pause</button>
        </div>

        <div>
          <h3>Deck B</h3>
          <audio ref={audioBRef} src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"/>
          <button onClick={()=>audioBRef.current.play()}>Play</button>
          <button onClick={()=>audioBRef.current.pause()}>Pause</button>
        </div>

      </div>

      <div style={{marginTop:30,width:400}}>
        <h3>Crossfader</h3>
        <input type="range" min="0" max="100" value={cross}
          onChange={e=>updateCross(e.target.value)}
          style={{width:"100%"}}/>
        <div>A ←→ B</div>
      </div>

    </div>
  );
}
