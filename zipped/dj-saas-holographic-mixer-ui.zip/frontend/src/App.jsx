
import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);

  useEffect(()=>{

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true, alpha:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 💡 Neon holographic material
    const holoMaterial = new THREE.MeshBasicMaterial({
      color:0x00f0ff,
      wireframe:true,
      transparent:true,
      opacity:0.9
    });

    // 🎛️ Floating Deck Panel A
    const panelGeo = new THREE.BoxGeometry(4,2,0.2);
    const deckA = new THREE.Mesh(panelGeo, holoMaterial);
    deckA.position.set(-3,1,0);
    scene.add(deckA);

    // 🎛️ Floating Deck Panel B
    const deckB = new THREE.Mesh(panelGeo, holoMaterial);
    deckB.position.set(3,1,0);
    scene.add(deckB);

    // 🎚️ Mixer Panel Center
    const mixerGeo = new THREE.BoxGeometry(2,3,0.2);
    const mixer = new THREE.Mesh(mixerGeo, holoMaterial);
    mixer.position.set(0,-0.5,0);
    scene.add(mixer);

    camera.position.z = 10;

    function animate(){
      requestAnimationFrame(animate);

      // holographic floating motion
      deckA.rotation.y += 0.005;
      deckB.rotation.y -= 0.005;
      mixer.rotation.y += 0.003;

      deckA.position.y = 1 + Math.sin(Date.now()*0.001)*0.1;
      deckB.position.y = 1 + Math.cos(Date.now()*0.001)*0.1;

      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div style={{background:"#02040a",height:"100vh"}}>
      <h1 style={{position:"absolute",color:"#00f0ff",padding:15,textShadow:"0 0 10px #00f0ff"}}>
        🧊 Holographic Mixer UI
      </h1>
      <div ref={mountRef}></div>
    </div>
  );
}
