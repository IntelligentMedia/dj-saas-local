
HOLOGRAPHIC MIXER UI

Features:
- 3D floating DJ decks
- Neon holographic panels
- Animated rotation and floating motion
- Three.js powered futuristic interface
