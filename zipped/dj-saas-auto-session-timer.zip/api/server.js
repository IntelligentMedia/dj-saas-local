
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const app = express();
app.use(cors());
app.use(express.json());

const SECRET="AUTO_SESSION_SECRET";

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=?",[username],async(err,rows)=>{
    if(!rows || rows.length===0) return res.status(401).send("Invalid");

    const user=rows[0];
    const match = await bcrypt.compare(password,user.password);
    if(!match) return res.status(401).send("Invalid");

    const token = jwt.sign({id:user.id,role:user.role},SECRET,{expiresIn:"2h"});
    res.json({accessToken:token,user:{username:user.username,role:user.role}});
  });
});

// AUTO TIMER CHECK EVERY 5 SECONDS
setInterval(()=>{
  db.query("SELECT * FROM bookings WHERE status='approved'",(err,rows)=>{
    const now = new Date();
    rows.forEach(b=>{
      const start = new Date(b.start_time);
      const end = new Date(start.getTime() + b.hours*60*60*1000);

      if(now>=start && now<=end){
        db.query("UPDATE sessions SET active=1 WHERE booking_id=?",[b.id]);
      }else{
        db.query("UPDATE sessions SET active=0 WHERE booking_id=?",[b.id]);
      }
    });
  });
},5000);

app.get("/sessions",auth,(req,res)=>{
  db.query("SELECT * FROM sessions",(err,rows)=>{
    res.json(rows);
  });
});

app.listen(4000,()=>console.log("Auto Session Timer API running"));
