
import React, { useState, useEffect } from "react";

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [sessions,setSessions]=useState([]);

  const getToken=()=>localStorage.getItem("accessToken");

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const data=await res.json();
      localStorage.setItem("accessToken",data.accessToken);
      setUser(data.user);
      loadSessions(data.accessToken);
    }else alert("Login failed");
  };

  const loadSessions=async(token=getToken())=>{
    const res=await fetch("http://localhost:4000/sessions",{
      headers:{Authorization:"Bearer "+token}
    });
    const data=await res.json();
    setSessions(data);
  };

  useEffect(()=>{
    if(user){
      const interval=setInterval(()=>loadSessions(),3000);
      return ()=>clearInterval(interval);
    }
  },[user]);

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Login</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return(
    <div style={{padding:20}}>
      <h1>Welcome {user.username} ({user.role})</h1>

      <h3>Auto Sessions</h3>
      {sessions.map(s=>(
        <div key={s.id}>
          Booking #{s.booking_id} | Status: {s.active ? "LIVE":"WAITING"}
        </div>
      ))}
    </div>
  );
}
