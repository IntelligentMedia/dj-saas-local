
import React from "react";
import "./neon.css";

export default function App(){
  return(
    <div className="neon-bg">
      <h1 className="neon-title">🎛️ Neon Pro DJ Interface</h1>

      <div className="panel-row">
        <div className="neon-panel">
          <h3>Deck A</h3>
          <button className="neon-btn">Play</button>
          <button className="neon-btn">Cue</button>
        </div>

        <div className="neon-panel">
          <h3>Deck B</h3>
          <button className="neon-btn">Play</button>
          <button className="neon-btn">Cue</button>
        </div>
      </div>

      <div className="neon-panel large">
        <h3>🌍 Broadcast Control</h3>
        <div className="neon-bar"></div>
      </div>
    </div>
  );
}
