
LIVEKIT CLUSTER LOAD BALANCER

System distributes DJs across multiple LiveKit nodes.

Example nodes:
ws://localhost:7880
ws://localhost:7882
ws://localhost:7884

Run multiple LiveKit servers on different ports.

Login:
dj1 / 1234
