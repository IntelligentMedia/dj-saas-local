
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { AccessToken } = require("livekit-server-sdk");

const app = express();
app.use(cors());
app.use(express.json());

// 🔥 MULTI LIVEKIT NODES
const LIVEKIT_NODES = [
  { url:"ws://localhost:7880", key:"devkey", secret:"secret" },
  { url:"ws://localhost:7882", key:"devkey", secret:"secret" },
  { url:"ws://localhost:7884", key:"devkey", secret:"secret" }
];

const AUTH_SECRET="CLUSTER_SECRET";

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=?",[username],async(err,rows)=>{
    if(!rows || rows.length===0) return res.status(401).send("Invalid");

    const user=rows[0];
    const match = await bcrypt.compare(password,user.password);
    if(!match) return res.status(401).send("Invalid");

    const token = jwt.sign({
      id:user.id,
      role:user.role,
      approved:user.approved
    },AUTH_SECRET,{expiresIn:"2h"});

    res.json({accessToken:token,user:{username:user.username,role:user.role}});
  });
});

// 🔥 LIVEKIT CLUSTER LOAD BALANCER
function chooseNode(){
  // Simple round-robin selection
  const node = LIVEKIT_NODES.shift();
  LIVEKIT_NODES.push(node);
  return node;
}

app.get("/cluster-token",auth,(req,res)=>{

  db.query("SELECT * FROM sessions WHERE active=1",(err,sessions)=>{

    if(!sessions || sessions.length===0)
      return res.send("DENIED: NO ACTIVE SESSION");

    const node = chooseNode();

    const at = new AccessToken(node.key,node.secret,{
      identity:"user-"+req.user.id
    });

    at.addGrant({
      roomJoin:true,
      room:"global-broadcast-room",
      canPublish:req.user.role==="dj",
      canSubscribe:true
    });

    res.send("NODE: "+node.url+" | TOKEN: "+at.toJwt());
  });

});

app.listen(4000,()=>console.log("LiveKit Cluster Load Balancer API running"));
