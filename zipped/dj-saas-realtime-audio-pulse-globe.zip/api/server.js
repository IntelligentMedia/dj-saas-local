
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/audio-energy",(req,res)=>{
  res.json({energy: Math.random()});
});

app.listen(4000,()=>console.log("Realtime Audio Pulse Globe API running"));
