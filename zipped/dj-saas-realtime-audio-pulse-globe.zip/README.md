
REALTIME AUDIO PULSE GLOBE SYSTEM

Features:
- Three.js 3D globe
- WebAudio analyser realtime energy
- Globe pulses with music
- DJ node color reacts to audio intensity
