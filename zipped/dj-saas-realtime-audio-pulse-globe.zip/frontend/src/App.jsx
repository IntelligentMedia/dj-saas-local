
import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export default function App(){

  const mountRef = useRef(null);
  const audioRef = useRef(null);

  useEffect(()=>{

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    mountRef.current.appendChild(renderer.domElement);

    // 🌍 Globe
    const geometry = new THREE.SphereGeometry(5,64,64);
    const material = new THREE.MeshBasicMaterial({wireframe:true});
    const globe = new THREE.Mesh(geometry, material);
    scene.add(globe);

    // 📡 DJ Node
    const nodeGeo = new THREE.SphereGeometry(0.2,16,16);
    const nodeMat = new THREE.MeshBasicMaterial();
    const node = new THREE.Mesh(nodeGeo,nodeMat);
    node.position.set(3,1,2);
    scene.add(node);

    camera.position.z = 12;

    // 🎧 WebAudio analyser
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();

    const audio = audioRef.current;
    const source = ctx.createMediaElementSource(audio);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;

    source.connect(analyser).connect(ctx.destination);

    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    function animate(){
      requestAnimationFrame(animate);

      analyser.getByteFrequencyData(dataArray);

      // compute average energy
      let sum = 0;
      for(let i=0;i<dataArray.length;i++){
        sum += dataArray[i];
      }
      const avg = sum / dataArray.length;

      // 🌍 pulse globe scale
      const scale = 1 + (avg/255)*0.3;
      globe.scale.set(scale,scale,scale);

      // 📡 node color energy
      const intensity = avg/255;
      node.material.color.setRGB(intensity,0.2,1-intensity);

      globe.rotation.y += 0.002;

      renderer.render(scene,camera);
    }

    animate();

    return ()=>{
      mountRef.current.removeChild(renderer.domElement);
    };

  },[]);

  return(
    <div>
      <audio
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      />
      <div style={{position:"absolute",color:"white",padding:10}}>
        🌍 Realtime Audio Pulse Globe System
        <br/>
        <button onClick={()=>audioRef.current.play()}>Play Audio</button>
      </div>
      <div ref={mountRef}></div>
    </div>
  );
}
