
import React, { useState } from "react";

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [token,setToken]=useState("");

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const data=await res.json();
      localStorage.setItem("auth",data.accessToken);
      setUser(data.user);
    }else alert("Login failed");
  };

  const requestGlobalToken=async()=>{
    const res = await fetch("http://localhost:4000/global-broadcast-token",{
      headers:{Authorization:"Bearer "+localStorage.getItem("auth")}
    });

    const text = await res.text();
    setToken(text);
  };

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Login</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return(
    <div style={{padding:20}}>
      <h1>{user.username} ({user.role})</h1>
      <button onClick={requestGlobalToken}>Join Global Broadcast</button>
      <div style={{marginTop:20,wordBreak:"break-all"}}>{token}</div>
    </div>
  );
}
