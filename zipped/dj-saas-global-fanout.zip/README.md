
GLOBAL BROADCAST FANOUT SYSTEM

One DJ publishes once → ALL pubs auto receive stream via global room.

Run LiveKit:
docker run --rm -p 7880:7880 -p 7881:7881 -e LIVEKIT_KEYS="devkey:secret" livekit/livekit-server

Login:
dj1 / 1234
pub1 / 1234
