
import React, { useState, useEffect } from "react";

function Bar({label,value}){
  return(
    <div style={{marginBottom:10}}>
      <div>{label}: {value}%</div>
      <div style={{background:"#eee",height:20,width:300}}>
        <div style={{background:"#4caf50",height:20,width:value+"%"}}></div>
      </div>
    </div>
  );
}

export default function App(){
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [data,setData]=useState(null);

  const login=async()=>{
    const res = await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });

    if(res.ok){
      const json=await res.json();
      localStorage.setItem("auth",json.accessToken);
      setUser(json.user);
    }else alert("Login failed");
  };

  useEffect(()=>{
    if(!user) return;

    const interval=setInterval(async()=>{
      const res=await fetch("http://localhost:4000/visual-dashboard",{
        headers:{Authorization:"Bearer "+localStorage.getItem("auth")}
      });
      const json=await res.json();
      setData(json);
    },2000);

    return ()=>clearInterval(interval);
  },[user]);

  if(!user){
    return(
      <div style={{padding:20}}>
        <h2>Login</h2>
        <input placeholder="username" onChange={e=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  if(!data) return <div style={{padding:20}}>Loading dashboard...</div>;

  return(
    <div style={{padding:20,fontFamily:"Arial"}}>
      <h1>🎧 Visual Pro DJ Dashboard</h1>

      <h3>💰 Live Earnings: ${data.earnings}</h3>
      <h3>🍻 Active Pubs: {data.activePubs}</h3>
      <h3>⏱ Session Minutes: {data.minutes}</h3>

      <Bar label="Node Load" value={data.nodeLoad}/>
      <Bar label="Stream Health" value={data.streamHealth}/>
      <Bar label="Edge Utilization" value={data.edgeUtil}/>
    </div>
  );
}
