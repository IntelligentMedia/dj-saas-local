
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const AUTH_SECRET="VISUAL_PRO_SECRET";

let sessionStart = Date.now();

function auth(req,res,next){
  const header=req.headers.authorization;
  if(!header) return res.sendStatus(401);
  const token=header.split(" ")[1];
  jwt.verify(token,AUTH_SECRET,(err,user)=>{
    if(err) return res.sendStatus(403);
    req.user=user;
    next();
  });
}

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  if(password!=="1234") return res.status(401).send("Invalid");

  const role = username.startsWith("dj") ? "dj":"pub";

  const token = jwt.sign({id:1,role},AUTH_SECRET,{expiresIn:"2h"});
  res.json({accessToken:token,user:{username,role}});
});

// 📈 VISUAL DASHBOARD DATA
app.get("/visual-dashboard",auth,(req,res)=>{

  const elapsedMs = Date.now() - sessionStart;
  const minutes = Math.floor(elapsedMs/60000);

  const earnings = ((minutes/60)*50).toFixed(2);
  const activePubs = Math.floor(Math.random()*10)+1;
  const nodeLoad = Math.floor(Math.random()*100);
  const streamHealth = Math.floor(Math.random()*100);
  const edgeUtil = Math.floor(Math.random()*100);

  res.json({
    earnings,
    activePubs,
    minutes,
    nodeLoad,
    streamHealth,
    edgeUtil
  });
});

app.listen(4000,()=>console.log("Visual Pro Dashboard API running"));
