
VISUAL PRO DJ DASHBOARD

Features:
- Visual bars for node load, stream health, edge utilization
- Live earnings display
- Active pubs counter
- Auto refresh every 2 seconds

Login:
dj1 / 1234
