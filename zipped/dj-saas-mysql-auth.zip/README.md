
MYSQL AUTH VERSION

1) Start XAMPP MySQL
2) Import xampp_schema.sql

API:
cd api
npm install
npm start

FRONTEND:
cd frontend
npm install
npm run dev

Login:
dj1 / 1234
pub1 / 1234
