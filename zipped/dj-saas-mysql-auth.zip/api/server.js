
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const SECRET="dj_secret_key";

const db = mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"dj_saas"
});

db.connect(()=>console.log("MySQL Connected"));

app.post("/login",(req,res)=>{
  const {username,password}=req.body;

  db.query("SELECT * FROM users WHERE username=? AND password=?",[username,password],(err,rows)=>{
    if(rows && rows.length>0){
      const user=rows[0];
      const token=jwt.sign({id:user.id},SECRET);
      res.json({token,user:{username:user.username,role:user.role}});
    }else res.status(401).send("Invalid");
  });
});

app.post("/pub/join",(req,res)=>{
  const {code}=req.body;
  db.query("SELECT * FROM activation_codes WHERE code=?",[code],(err,rows)=>{
    if(rows && rows.length>0) res.json({ok:true});
    else res.status(403).send("Invalid");
  });
});

app.listen(4000,()=>console.log("API running 4000"));
