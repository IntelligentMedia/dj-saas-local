
import React, { useState, useRef } from "react";

export default function App() {
  const [user,setUser]=useState(null);
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const [activationInput,setActivationInput]=useState("");
  const [connectedPubs,setConnectedPubs]=useState([]);

  const videoCanvas = useRef(null);
  const masterStream = useRef(null);

  const login=async()=>{
    const res=await fetch("http://localhost:4000/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });
    if(res.ok){
      const data=await res.json();
      setUser(data.user);
    }else alert("Login Failed");
  };

  const startBroadcast=()=>{
    const canvasStream = videoCanvas.current.captureStream(30);
    masterStream.current = canvasStream;
  };

  const joinPub=async()=>{
    const res=await fetch("http://localhost:4000/pub/join",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({code:activationInput})
    });
    if(res.ok){
      setConnectedPubs(p=>[...p,{id:Date.now(),stream:masterStream.current}]);
    }else alert("Invalid Code");
  };

  if(!user){
    return (
      <div style={{padding:20}}>
        <h2>Login</h2>
        <input placeholder="username" onChange={(e)=>setUsername(e.target.value)}/>
        <input placeholder="password" type="password" onChange={(e)=>setPassword(e.target.value)}/>
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return (
    <div style={{padding:20}}>
      <h1>Welcome {user.username}</h1>

      {user.role==="dj" && (
        <div>
          <button onClick={startBroadcast}>Start Broadcast</button>
          <canvas ref={videoCanvas} width={640} height={360} style={{border:"1px solid"}}/>
        </div>
      )}

      {user.role==="pub" && (
        <div>
          <input onChange={(e)=>setActivationInput(e.target.value)}/>
          <button onClick={joinPub}>Join Stream</button>

          {connectedPubs.map(pub=>(
            <video key={pub.id} autoPlay playsInline
              ref={(el)=>{ if(el && pub.stream) el.srcObject=pub.stream }}
              style={{width:"100%"}}/>
          ))}
        </div>
      )}
    </div>
  );
}
