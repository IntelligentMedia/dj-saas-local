
CREATE DATABASE IF NOT EXISTS dj_saas;
USE dj_saas;

CREATE TABLE users(
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50),
 password VARCHAR(50),
 role VARCHAR(10)
);

CREATE TABLE activation_codes(
 id INT AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(50)
);

INSERT INTO users(username,password,role) VALUES('dj1','1234','dj');
INSERT INTO users(username,password,role) VALUES('pub1','1234','pub');

INSERT INTO activation_codes(code) VALUES('PUB-555');
